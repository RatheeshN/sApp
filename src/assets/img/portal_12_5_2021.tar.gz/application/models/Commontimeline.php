<?php
Class Commontimeline extends CI_model{
    function get_single_post($id)
	{
		
		$user_data=$this->session->userdata('loggedin');
		$cur_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];
		$post_content=array();
		$post_comment=array();
		$query=$this->db->query("SELECT * FROM `timeline_posts` WHERE `id`='$id'");
		foreach($query->result() as $row)
		{
			$cmntquery=$this->db->query("SELECT * FROM `timeline_post_comments` WHERE post_id='$row->id'");
			foreach($cmntquery->result() as $crow)
			{
				$post_comment[]=array('id'=>$crow->id,'post_id'=>$crow->post_id,'user_id'=>$crow->user_id,'user_name'=>$crow->user_name,'user_photo'=>$crow->user_photo,'comment'=>$crow->comment);
			}
			if($row->type=='share')
			{
				$post_id=$row->parent;
			}
			else{
				$post_id=$row->id;
			}
			
			$cquery=$this->db->query("SELECT * FROM `timeline_post_content` WHERE post_id='$post_id'");
			$post_content=array();
			foreach($cquery->result() as $row1)
			{
				$youtube_id='';
				$thumbnail='';
				$content=$row1->content;
				$regex_pattern = "/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/";
				$match;
				if($row1->type=='youtube')
				{
					if(preg_match($regex_pattern, $content, $match)){
						preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $content, $match);
						$youtube_id = $match[1];
					}
				}
				if($row1->type=='video_upload')
				{

					$hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/".$row1->content.".php"));
					$thumbnail=$hash[0]['thumbnail_large'];
				}
				$post_content[]=array('type'=>$row1->type,'content'=>$row1->content,'youtube_id'=>$youtube_id,'thumbnail'=>$thumbnail);
			}
			
			
			if($row->user_id==$cur_id)
			{
				$show_edit='1';
			}
			else{
				$show_edit='0';
			}
			$like_query=$this->db->query("SELECT * FROM `timeline_post_likes` WHERE post_id='$row->id'");
			$like_count=$like_query->num_rows();
			$you_liked=$this->db->query("SELECT * FROM `timeline_post_likes` WHERE post_id='$row->id' AND `user_id`='$cur_id'");
			$you_liked_count=$you_liked->num_rows();
			if($you_liked_count>0)
			{
				$youlike='true';
			}
			else{
				$youlike='';
			}
			$date=date("j F Y", strtotime($row->added_date));
			$pname='';
			$status='';
			if($row->type=='share')
			{
				$pid=$row->parent;
				$pquery=$this->db->query("SELECT `user_name` FROM `timeline_posts` WHERE id='$pid'");
				$cnt=$pquery->num_rows();
				if($cnt<=0)
				{
					$status='deleted';
				}
				$prow=$pquery->row_array();
				$pname=$row->parent_name;
			}
			
			$post_data[]=array('id'=>$row->id,'user_id'=>$row->user_id,'user_name'=>$row->user_name,'user_photo'=>$row->user_photo,'des'=>$row->description,'show_edit'=>$show_edit,'likes'=>$like_count,'you_like'=>$youlike,'date'=>$date,'type'=>$row->type,'parent'=>$row->parent,'pname'=>$pname,'content'=>$post_content,'comment'=>$post_comment,'status'=>$status);
			$post_content=array();
			$post_comment=array();
		}
		if(isset($post_data))
		return $post_data;
	}
}
?>