<?php
Class Elearning extends CI_model{

	public function __construct()
	{
		parent::__construct();
		
		
	}
    function get_chapter_topic($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$data=json_decode($postdata);
		$subject_id=$data->subject;
		$tdata=array();
		isset($data->course)?$course=$data->course:$course=$user_data['course'];
		isset($data->standard)?$standard=$data->standard:$standard=$user_data['standard'];
		isset($data->division)?$division=$data->division:$division=$user_data['division'];
		$query = $this->db->query("SELECT * FROM elearning_topics WHERE course_id=$course AND standard_id=$standard AND subject_id='$subject_id' ORDER BY sort_order ASC");
		foreach ($query->result() as $row)
		{	
			if($this->admin_settings->handle_division=='true')
			{
				$cqry=$this->db->query("SELECT * FROM `elearning_contents` WHERE `topic_id`=$row->id AND division_id=$division");
			}
			else
			{
				$cqry=$this->db->query("SELECT * FROM `elearning_contents` WHERE `topic_id`=$row->id");
			}
			
			if($cqry->num_rows()>0)
			{
				$crow=$cqry->row_array();
				$save_status=$crow['status'];
				$approval_status=$crow['approval_status'];
				$have_contents=true;
				$reject_reason=$crow['reject_reason'];
			}
			else
			{
				$save_status='';
				$approval_status='';
				$have_contents=false;
				$reject_reason='';
			}
			$viewed=false;
			
			if($user_data['user_type']=='Student')
			{
				$viewed_by = explode(',',$row->viewed_by);
				if (in_array($user_data['student_id'], $viewed_by))
				{
					$viewed=true;
				}
			}
			$tdata[]=array('id'=>$row->id,'title'=>$row->name,'parent_id'=>$row->parent,'type'=>$row->type,'delete_status'=>$row->delete_status,'save_status'=>$save_status,'approval_status'=>$approval_status,'reject_reason'=>$reject_reason,'have_contents'=>$have_contents,'viewed'=>$viewed);
		}
		$tdata=array('nodes'=>$this->buildTree($tdata));
		
		if(isset($tdata))
		{ 
			return $tdata;
		}		
		else
		{
			return false;
		}
	}

	function add_chapter_topic($data,$table)
    {
		$this->db->insert($table,$data);
		$id=$this->db->insert_id();
		$query = $this->db->query("SELECT * FROM elearning_topics WHERE `id`=$id");	
		return $query->row_array();
		
    }
	
	function update_chapter_topic_order($data)
	{
		$this->recursive($data);
	}
	function delete_chapter_topic($postdata)
	{
		if($postdata->del_has_sub==false)
		{
			if($this->db->query("DELETE FROM `elearning_topics` WHERE `id`=$postdata->id"))
			{
				return true;
			}
		}
		else
		{
			if($postdata->delete_sub==true)
			{
				if($this->db->query("DELETE FROM `elearning_topics` WHERE `id`=$postdata->id"))
				{
					if($this->db->query("DELETE FROM `elearning_topics` WHERE `parent`=$postdata->id"))
					{
						return true;
					}
				}
			}
			else{
				if($this->db->query("UPDATE `elearning_topics` SET `delete_status`='1',`name`='Unnamed' WHERE `id`=$postdata->id"))
				{
					return true;
				}
			}
		}
	}

	public function get_content($id,$division)
	{ 
		$user_data=$this->session->userdata('loggedin');
		$content=array('id'=>'','topic_id'=>$id,'description'=>'','heading'=>'','division'=>'','status'=>'','approval_status'=>'','reject_reason'=>'','last_updated'=>'','views'=>0,'videos'=>array(),'docs'=>array());
		if($this->admin_settings->handle_division=='true')
		{
			$qry=$this->db->query("SELECT * FROM `elearning_contents` WHERE topic_id='$id' AND division_id=$division");
			if($this->admin_settings->student_show_multiple_divisions=='true')
			{
				$dvqry=$this->db->query("SELECT * FROM `elearning_contents` WHERE topic_id='$id' AND division_id!=$division");
				if($dvqry->num_rows())
				{
					$content['oth_divs']=array();
					foreach($dvqry->result() as $divs)
					{
						$content['oth_divs'][]=(int)$divs->division_id;
					}
					
				}
			}
		}
		else
		{
			$qry=$this->db->query("SELECT * FROM `elearning_contents` WHERE topic_id='$id'");
		}
		
		if($qry->num_rows())
		{
			$tqry = $this->db->query("SELECT * FROM elearning_topics WHERE id='$id'");
			$trow=$tqry->row_array(); 
			
			$cnts=$qry->row_array();
			$cnt_id=$cnts['id'];
			$content['id']=$cnt_id;
			$content['description']=$cnts['description'];
			$content['division']=$cnts['division_id'];
			$content['status']=$cnts['status'];
			$content['approval_status']=$cnts['approval_status'];
			$content['reject_reason']=$cnts['reject_reason'];
			$content['last_updated']=date('M j, Y h:m a',strtotime($cnts['last_updated']));
			$content['veiws']=$trow['views'];
			$heading=$this->generate_heading($id,$id);
			$content['heading']=$heading;
			if($this->admin_settings->handle_division=='true')
			{
				$dqry=$this->db->query("SELECT * FROM `elearning_documents` WHERE topic_id='$id' AND division_id=$division");
			}
			else
			{
				$dqry=$this->db->query("SELECT * FROM `elearning_documents` WHERE topic_id='$id'");
			}
			foreach ($dqry->result() as $docs)
			{
				$content['docs'][]=array('id'=>$docs->id,'file_id'=>$docs->file_id,'type'=>$docs->type,'name'=>$docs->name,'size'=>$docs->size,'status'=>'saved');
			}
			if($this->admin_settings->handle_division=='true')
			{
				$vqry=$this->db->query("SELECT * FROM `elearning_videos` WHERE topic_id='$id' AND division_id=$division");
			}
			else
			{
				$vqry=$this->db->query("SELECT * FROM `elearning_videos` WHERE topic_id='$id'");
			}
			foreach ($vqry->result() as $videos)
			{
				if($videos->type=='vimeo')
				{
					$path= "https://api.vimeo.com/videos/$videos->video_id/pictures";
					$headers = array('Content-Type' => 'application/json','Authorization' => 'Bearer 9a7ac77e368b1f685325942e28f7853f');
					$response = Requests::get($path,$headers);
					   $data=json_decode($response->body,true);
					$thumb=$data['data'][0]['sizes'][1]['link'];
					$embed_url="https://player.vimeo.com/video/".$videos->video_id;
				}
				else{
					$thumb="//i3.ytimg.com/vi/$videos->video_id/hqdefault.jpg";
					$embed_url="https://www.youtube.com/embed/".$videos->video_id;
				}
				$content['videos'][]=array('id'=>$videos->id,'video_id'=>$videos->video_id,'url'=>$videos->url,'type'=>$videos->type,'thumb'=>$thumb,'embed_url'=>$embed_url);
			}
			
			if($user_data['user_type']=='Student')
			{
				if($content['description'] != '' || count($content['videos'])==0 || count($content['docs'])==0)
				{
					$viewed_by = explode(',',$trow['viewed_by']);
					if (!in_array($user_data['student_id'], $viewed_by))
					{
						if($trow['viewed_by'] =='')
						{
							$nviewed_by=$user_data['student_id'];
						}
						else
						{
							$nviewed_by=$trow['viewed_by'].','.$user_data['student_id'];
						}
						$views=$trow['views']+1;
						$this->db->query("UPDATE elearning_topics SET `viewed_by`='$nviewed_by',`views`=$views WHERE id='$id'");
					}
					
				}
			}
			return $content;
		}
		else{
			return $content;
		}
	}
	public function update_content($content)
	{
		$user_data=$this->session->userdata('loggedin');
		$uid=$user_data['uid'];
		$date=date('Y-m-d H:i:s');
		if($this->admin_settings->handle_division=='true')
		{
			$division=$content->division;
		}
		else
		{
			$division=0;
		}
		if($content->id!="")
		{
			if($user_data['user_type']=='Admin')
			{
				$approval_status='approved';
			}
			else
			{
				if($this->conf->faculty->fc_elearning_approval==1)
				{
					$approval_status='pending';
				}
				else
				{
					$approval_status='approved';
				}
			}
			
			$qry=$this->db->query("UPDATE `elearning_contents` SET `topic_id`=$content->topic_id,`description`='$content->description',`status`='draft',`approval_status`='pending',`last_updated_by`='$uid',`division_id`='$division' WHERE id='$content->id'");

			$this->db->query("DELETE FROM `elearning_documents` WHERE topic_id='$content->topic_id' AND `division_id`='$division'");
			foreach($content->docs as $docs)
			{
				$this->db->query("INSERT INTO `elearning_documents`(`topic_id`, `file_id`, `name`, `size`, `type`, `added_date`,`division_id`) VALUES ('$content->topic_id','$docs->file_id','$docs->name','$docs->size','$docs->type','$date','$division')");
			}
			$this->db->query("DELETE FROM `elearning_videos` WHERE topic_id='$content->topic_id' AND `division_id`='$division'");
			foreach($content->videos as $videos)
			{
				if($videos->url!='')
				{
					if($videos->type=='youtube')
					{
						preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $videos->url, $match);
						$videos->video_id = $match[1];					
					}
					$this->db->query("INSERT INTO `elearning_videos`(`topic_id`, `type`, `video_id`, `url`, `added_date`,`division_id`) VALUES ($content->topic_id,'$videos->type','$videos->video_id','$videos->url','$date','$division')");
				}
			}
			return true;
		}
		else{		
			$qry=$this->db->query("INSERT INTO `elearning_contents`( `topic_id`, `description`, `status`, `approval_status`, `reject_reason`, `added_date`,`division_id`) VALUES ($content->topic_id,'$content->description','draft','pending','','$date','$division') ");	
			$insert_id = $this->db->insert_id();
   			return  array('status'=>'added','id'=>$insert_id);		
		}
	}    
	 public function publish_content($content)
	 {
		if($this->admin_settings->handle_division=='true')
		{
			$division=$content->division;
		}
		else
		{
			$division=0;
		}
		if($this->update_content($content))
		{
			if($this->db->query("UPDATE `elearning_contents` SET `status`='published' WHERE `topic_id`=$content->topic_id AND `division_id`=$division"))
			{
				return true;
			}
		}

	 }

	 public function get_subject_icon($postdata)
	 { 
		 $icons=array();
		 $qry=$this->db->query("SELECT * FROM `subject_icons` WHERE `course_id`='$postdata->course' AND `standard_id`='$postdata->standard' AND `subject_id`='$postdata->subject' ");
		 if($qry->num_rows()>0)
		 {
			$icons=$qry->row_array();
		 }
		 return $icons;
	 }

	 public function save_subject_icon($postdata)
	 {
		 $icons=array();
		 $qry=$this->db->query("SELECT * FROM `subject_icons` WHERE `course_id`='$postdata->course' AND `standard_id`='$postdata->standard' AND `subject_id`='$postdata->subject' ");
		 if($qry->num_rows()>0)
		 {
			if($this->db->query("UPDATE `subject_icons` SET `icon`='$postdata->icon',`type`='$postdata->type' WHERE `course_id`='$postdata->course' AND `standard_id`='$postdata->standard' AND `subject_id`='$postdata->subject'"))
			{
				return $this->get_subject_icon($postdata);
			}
		 }
		 else
		 {
			 if($this->db->query("INSERT INTO `subject_icons`(`course_id`, `standard_id`, `subject_id`, `icon`, `type`) VALUES ('$postdata->course','$postdata->standard','$postdata->subject','$postdata->icon','$postdata->type')"))
			 {
				return $this->get_subject_icon($postdata);
			 }
		 }
		 
	 }
	
	 
	public function get_pending_elearning()
	{
		$user_data=$this->session->userdata('loggedin');
		$qry=$this->db->query("SELECT et.name,et.standard_id,et.subject_id,ec.id FROM elearning_topics et LEFT JOIN elearning_contents ec ON ec.topic_id=et.id WHERE  ec.approval_status='pending' AND ec.status='published'");
		$pending_list=array();
		foreach ($qry->result() as $row)
		{
			$jsonData = array('params'=>array(
				'standard_id'=>(int)$row->standard_id
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $subjects)
			{
				if($subjects['subject_id']==$row->subject_id)
				{
					$subject=$subjects['name'];
				}
			}
			$pending_list[]=array('id'=>$row->id,'topic'=>$row->name,'subject'=>$subject);
		}
		return $pending_list;
	}

	public function approve_elearning($id)
	{
		$qry=$this->db->query("UPDATE `elearning_contents` SET `approval_status`='approved' WHERE `id`='$id'");
		if($qry)
		{
			return true;
		}
	}

	public function reject_elearning($id,$note)
	{
		$qry=$this->db->query("UPDATE `elearning_contents` SET `approval_status`='rejected',`reject_reason`='$note' WHERE `id`='$id'");
		if($qry)
		{
			return true;
		}
	}

	public function get_percentage($subject)
	{
		$user_data=$this->session->userdata('loggedin');
		$student_id=$user_data['student_id'];
		$course_id=$user_data['course'];
		$standard_id=$user_data['standard'];
		$qry=$this->db->query("SELECT COUNT(*) AS total_topics,(SELECT count(*) FROM `elearning_topics` WHERE FIND_IN_SET('122',`viewed_by`)> 0 AND `standard_id`='$standard_id' AND `course_id`='$course_id') AS viewcount FROM `elearning_topics` WHERE `subject_id`='$subject' AND `standard_id`='$standard_id' AND `course_id`='$course_id'");
		$data=$qry->row_array();
		$percentage=round(($data['viewcount']/$data['total_topics'])*100);
		return array('percentage'=>$percentage);
	}

	public function get_last_updated($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		if($this->admin_settings->handle_division=='true')
		{
			$division=$user_data['division'];
		}
		else
		{
			$division=0;
		}
		
		$qry=$this->db->query("SELECT et.id,et.division_id,ec.last_updated  FROM `elearning_topics` et LEFT JOIN `elearning_contents` ec ON ec.topic_id=et.id WHERE ec.division_id=et.division_id AND et.subject_id=$postdata->subject AND et.course_id=$postdata->course AND et.standard_id=$postdata->standard ORDER BY ec.last_updated DESC LIMIT 1 ");
		if($qry->num_rows())
		{
			$date=$qry->row_array();
			$output=array('date'=>date('M j, Y h:m a',strtotime($date['last_updated'])));
		}
		else
		{
			$output=array('date'=>'No contents');
		}
		return $output;
	}
    public function buildTree(array $elements, $parentId = 0) {
		$branch = array();
	
		foreach ($elements as $element) {
			
			if ($element['parent_id'] == $parentId) {
				
				$children = $this->buildTree($elements, $element['id']);
				
				$element['nodes'] = $children;
				
				$branch[] = $element;
			}
						
		}	
		return $branch;
    }
    function recursive($array,$order=1,$parent=0,$level=1,$type='c'){
		foreach($array as $item){ 	
			if($level==1)
			{
				$parent=0;
				$type='c';
			}
			$id=$item['id'];
			$this->db->query("UPDATE elearning_topics SET `sort_order`=$order,`parent`=$parent, `type`='$type' WHERE `id`=$id" );
			$order++;
			//echo $item['title'] .'-'. $parent;
			//If $value is an array.
			if(count($item['nodes'])>0){
				$parent=$id;
				$type='t';
				//We need to loop through it.
				$this->recursive($item['nodes'], $order,$parent,$level+1,$type);
				$order++;
			} 
						
		}
	}
	
	public function generate_heading($id,$current,$except = null)
	{
		$qry=$this->db->query("SELECT * FROM `elearning_topics` WHERE `id`='$id'");
		$row=$qry->row_array();
		if($row['id']==$current)
		{
			$except = $row['name'];
		}
		if($row['parent']==0)
		{
			if(!empty($except) && $except == $row['name']){
				
				return $row['name'];
			}
			else
			{
				return $row['name'] .' >';		
			}	
		}
		else{
			if(!empty($except) && $except == $row['name']){
				
				return $this->generate_heading($row['parent'],$except)." ".$row['name'];
			}
			return $this->generate_heading($row['parent'], $except). " ".$row['name']." >";
		}
	}
	
}
?>