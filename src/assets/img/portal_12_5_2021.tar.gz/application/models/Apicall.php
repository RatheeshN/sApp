<?php
Class Apicall extends CI_model{

    function callAPI($postData,$path)
    {
        $user_data=$this->session->userdata('loggedin');
        if(isset($user_data))
        {
            $session_id=$user_data['session_id'];
        }
        else
        {
            $session_id='';
        }
        $jsonDataEncoded = json_encode($postData,JSON_UNESCAPED_SLASHES);
		
		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$session_id);
		$response = Requests::post($path,$headers,$jsonDataEncoded);
        $data=json_decode($response->body,true);//print_r($data);
        if(isset($data['result']))
        {
            $response=$data['result'];
        }
        else{
            if(isset($data['error']))
            {
                $response=$data['error'];
            }
            else{
                $response='API error';
            }            
        }
		return $response;
    }
}
?>