<?php
Class Lessonplanner extends CI_model{
   
    function list_plans()
    {
        $user_data=$this->session->userdata('loggedin');
        $standard=$user_data['standard'];
        $division=$user_data['division'];
        $acd_year=$user_data['acd_year'];
        $query=$this->db->query("SELECT * FROM `lesson_planner` WHERE `standard`='$standard' AND `division`='$division' AND `acd_year`='$acd_year'");
        foreach($query->result() as $row)
        {
            $date=date_create($row->date);
            $date=date_format($date,"F j, Y");
            
            $cdate=date_create($row->completed_date);
            $cdate=date_format($cdate,"F j, Y");
            $subject=$row->subject;
            $user_data=$this->session->userdata('loggedin');       

            $data[]=array('id'=>$row->id,'subject'=>$row->subject,'chapter'=>$row->chapter,'topic'=>$row->topic,'due_date'=>$date,'completed_date'=>$cdate,'status'=>$row->status);
        }
        if(isset($data))
        {
            return $data;
        }
    }
}
?>