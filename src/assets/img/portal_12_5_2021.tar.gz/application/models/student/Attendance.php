<?php
Class Attendance extends CI_model{
	function apply_leave($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$data=json_decode($postdata);
		$start=date("Y-m-d",strtotime($data->start));
		$end=date("Y-m-d",strtotime($data->end));
		$message=$data->message;
		$date=date('Y-m-d H:i:s');
		if($this->db->query("INSERT INTO `leave_applications`(`student_id`, `standard_id`, `division_id`, `start`, `end`, `message`, `applied_date`) VALUES ('$stu_id','$standard','$division','$start','$end','$message','$date')"))
		{
			return true;
		}
	}
	function leave_list()
	{
		$user_data=$this->session->userdata('loggedin');
		$stu_id=$user_data['student_id'];
		$query=$this->db->query("SELECT * FROM `leave_applications` WHERE `student_id`='$stu_id' ORDER BY `id` DESC");
		foreach($query->result() as $row)
		{
			$start=date_create($row->start);
			$start=date_format($start,"F j, Y");
			$end=date_create($row->end);
			$end=date_format($end,"F j, Y");
			if($start==$end)
			{
				$date=$start;
			}
			else{
				$date=$start.' - '.$end;
			}
			$data[]=array('id'=>$row->id,'date'=>$date,'message'=>$row->message,'status'=>$row->status);
		}
		if($data)
		{
			return $data;
		}
	}
	function update_todo($postdata)
	{
		$postdata=json_decode($postdata);
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$max=sizeof($postdata);
		for($i=0; $i<$max; $i++) { 
			$id=$postdata[$i];
			$query = $this->db->query("SELECT completed_id FROM todo WHERE standard_id='$standard' AND division_id='$division' AND id='$id'");
			$row = $query->row_array();
			$completed= $row['completed_id'];
			if($completed)
			{
				$completed=$completed.','.$stu_id;
			}
			else
			{
				$completed=$stu_id;
			}
			$this->db->query("UPDATE `todo` SET `standard_id`='$standard',`division_id`='$division',`completed_id`='$completed' WHERE id='$id'");
			
		}
		return true;
	}
}

?>