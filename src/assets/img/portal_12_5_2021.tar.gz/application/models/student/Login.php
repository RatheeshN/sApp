<?php
Class Login_model extends CI_model{
	function validate()
	{
		
	}
}

?>