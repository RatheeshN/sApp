<?php
Class Notifications extends CI_model{
   
    function get_notifications()
    {
        $user_data=$this->session->userdata('loggedin');
		$student_id=$user_data['student_id'];
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		
		$query=$this->db->query("SELECT * FROM student_notifications WHERE (`standard_id`='$standard' AND `division_id`='$division') OR `to_id`='$student_id' ORDER BY id DESC LIMIT 5");
		foreach ($query->result() as $row)
		{
			$module=ucfirst($row->module);
			$seen_ids = explode(',',$row->seen_ids);
			if (in_array($student_id, $seen_ids)) {
				$seen=1;
			} else {
				$seen=0;
			}
			$read_ids = explode(',',$row->read_ids);
			if (in_array($student_id, $read_ids)) {
				$read=1;
			} else {
				$read=0;
			}
			$data[]=array('id'=>$row->id,'module_name'=>$row->module,'module'=>$module,'date'=>$row->date,'message'=>$row->message,'url'=>$row->url,'item_id'=>$row->item_id,'seen'=>$seen,'read'=>$read);			
		}
        if(isset($data))
        {
            return $data;
        }
        else{
            return false;
        }
    }
    
    function get_new_notifications($postdata)
    {
        $postdata=json_decode($postdata);
        $id=$postdata->id;
        $user_data=$this->session->userdata('loggedin');
		$student_id=$user_data['student_id'];
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		
		$query=$this->db->query("SELECT * FROM student_notifications WHERE `id`>$id AND ( (`standard_id`='$standard' AND `division_id`='$division') OR `to_id`='$student_id') ORDER BY id ASC");
		foreach ($query->result() as $row)
		{
			$module=ucfirst($row->module);
			$seen_ids = explode(',',$row->seen_ids);
			if (in_array($student_id, $seen_ids)) {
				$seen=1;
			} else {
				$seen=0;
			}
			$read_ids = explode(',',$row->read_ids);
			if (in_array($student_id, $read_ids)) {
				$read=1;
			} else {
				$read=0;
			}
			$data[]=array('id'=>$row->id,'module_name'=>$row->module,'module'=>$module,'date'=>$row->date,'message'=>$row->message,'url'=>$row->url,'item_id'=>$row->item_id,'seen'=>$seen,'read'=>$read);			
		}
        if(isset($data))
        {
            return $data;
        }
        else{
            return false;
        }
	}
	
	function make_all_seen()
	{
		
        $user_data=$this->session->userdata('loggedin');
		$student_id=$user_data['student_id'];
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		
		$query=$this->db->query("SELECT `id`,`seen_ids` FROM student_notifications WHERE  (`standard_id`='$standard' AND `division_id`='$division') OR `to_id`='$student_id'");
		foreach ($query->result() as $row)
		{
			$seen=$row->seen_ids;
			$id=$row->id;
			if($seen!='')
			{
				$seen=$seen.','.$student_id;
			}
			else
			{
				$seen=$student_id;
			}
			$this->db->query("UPDATE student_notifications SET seen_ids='$seen' WHERE id='$id'");
		}
	}

	function get_all_notifications($postdata)
    {
        $user_data=$this->session->userdata('loggedin');
		$student_id=$user_data['student_id'];
		$standard=$user_data['standard'];
		$division=$user_data['division'];

		$postdata = json_decode($postdata);
        $start = $postdata->start;
        $limit = $postdata->limit;
		
		$data = array();
		$query=$this->db->query("SELECT * FROM student_notifications WHERE (`standard_id`='$standard' AND `division_id`='$division') OR `to_id`='$student_id' ORDER BY id DESC LIMIT $start, $limit");
		foreach ($query->result() as $row)
		{
			$module=ucfirst($row->module);
			$seen_ids = explode(',',$row->seen_ids);
			if (in_array($student_id, $seen_ids)) {
				$seen=1;
			} else {
				$seen=0;
			}
			$read_ids = explode(',',$row->read_ids);
			if (in_array($student_id, $read_ids)) {
				$read=1;
			} else {
				$read=0;
			}
			$data[]=array('id'=>$row->id,'module_name'=>$row->module,'module'=>$module,'date'=>$row->date,'message'=>$row->message,'url'=>$row->url,'item_id'=>$row->item_id,'seen'=>$seen,'read'=>$read);			
		}
        return $data;
	}
	
	public function add_notification($to_id, $standard_id, $division_id, $module, $item_id, $url, $message, $seen_ids, $read_ids){
		$sql = "INSERT INTO `student_notifications` (`to_id`, `standard_id`, `division_id`, `module`, `item_id`, `url`, `message`, `seen_ids`, `read_ids`, `date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
		$result = $this->db->query($sql, array($to_id, $standard_id, $division_id, $module, $item_id, $url, $message, $seen_ids, $read_ids));
		return $result;
	}

	public function add_teacher_notification($teacher_id, $module, $item_id, $message, $seen_status, $read_status){
        $sql = "insert into teacher_notifications (teacher_id, module, item_id, message, seen_status, read_status) values (?, ?, ?, ?, ?, ?)";
        $result = $this->db->query($sql, array($teacher_id, $module, $item_id, $message, $seen_status, $read_status));
		return $result;
    }
}
?>