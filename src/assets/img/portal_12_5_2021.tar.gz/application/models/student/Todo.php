<?php
Class Todo extends CI_model{
	function get_todo()
	{
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];
        if($this->conf->faculty->fc_todo_approval=='1')
       	{
			$query = $this->db->query("SELECT * FROM todo WHERE standard_id='$standard' AND division_id='$division' AND acd_year='$acd_year' AND status='approved' ORDER BY `created_date` DESC");
		}
		else
		{
			$query = $this->db->query("SELECT * FROM todo WHERE standard_id='$standard' AND division_id='$division' AND acd_year='$acd_year' ORDER BY `created_date` DESC");
		}
		foreach ($query->result() as $row)
		{
			$id=$row->id;
			$delivered=explode(',' ,$row->delivered_id);
			if (in_array($stu_id, $delivered))
			{
				
			}
			else
			{
				if($row->delivered_id!='')
				{
					$delivered_ids=$row->delivered_id.','.$stu_id;
				}
				else {
					$delivered_ids=$stu_id;
				}
				
				$this->db->query("UPDATE `todo` SET `delivered_id`='$delivered_ids' WHERE `id`='$id'");
			}
			$list = $row->completed_id;
			$commaseparatedlist = explode(',',$list);
			if (in_array($stu_id, $commaseparatedlist)) 
			{
			  $status='completed';
			} 
			else {
			  $status='pending';
			}
			$date=date_create($row->date);
			$date=date_format($date,"d/m/Y");
			$data[]=array('id'=>$row->id,'topic'=>$row->topic,'description'=>$row->description,'date'=>$date,'status'=>$status,'course'=>$row->course_id,'standard'=>$row->standard_id,'division'=>$row->division_id,'subject'=>$row->topic);
		}
		if(isset($data))
		{
			return $data;
		}
		else
		{
			return false;
		}
	}
	function update_todo($postdata)
	{
		$postdata=json_decode($postdata);
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$max=sizeof($postdata);
		for($i=0; $i<$max; $i++) { 
			$id=$postdata[$i];
			$query = $this->db->query("SELECT completed_id FROM todo WHERE standard_id='$standard' AND division_id='$division' AND id='$id'");
			$row = $query->row_array();
			$completed= $row['completed_id'];
			if($completed)
			{
				$completed=$completed.','.$stu_id;
			}
			else
			{
				$completed=$stu_id;
			}
			$this->db->query("UPDATE `todo` SET `standard_id`='$standard',`division_id`='$division',`completed_id`='$completed' WHERE id='$id'");
			$todo = $this->get_todo_details($id);

			$student = $user_data["name"];
			$message = $student." completed todo - '". ((strlen($todo[0]['description']) > 52) ? substr($todo[0]['description'], 0, 52).'..' : $todo[0]['description'])."'";
			//$this->notifications->add_teacher_notification($todo[0]['teacher_id'], 'todo', $id, $message, 0, 0);
		}
		return true;
	}

	function get_todo_details($id){
		$sql = "SELECT `id`, `teacher_id`, `course_id`, `standard_id`, `division_id`, `topic`, `description`, `date`, `completed_id`, `acd_year` FROM `todo` WHERE `id`=?";
		$query = $this->db->query($sql, array($id));
		$row = $query->row_array();
		$result[] = array(
				'id' => $row['id'],
				'teacher_id' => $row['teacher_id'],
				'course_id' => $row['course_id'],
				"standard_id" => $row['standard_id'],
				"division_id" => $row['division_id'], 
				"topic" => $row['topic'], 
				"description" => $row['description'], 
				"date" => $row['date'], 
				"completed_id" => $row['completed_id'], 
				"acd_year" => $row['acd_year']
			);
		return $result;
	}
	public function get_single_todo($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$user_data=$this->session->userdata('loggedin');
		$acd_year=$user_data['acd_year'];
		$stu_id=$user_data['student_id'];
		$query = $this->db->query("SELECT * FROM todo WHERE acd_year='$acd_year' AND id='$id'");
		$row= $query->row_array();

		$read=explode(',' ,$row['read_id']);
		if (in_array($stu_id, $read))
		{
			
		}
		else
		{
			if($row['read_id']!='')
			{
				$read_ids=$row['read_id'].','.$stu_id;
			}
			else {
				$read_ids=$stu_id;
			}
			
			$this->db->query("UPDATE `todo` SET `read_id`='$read_ids' WHERE `id`='$id'");
		}

		$subject=$row['topic'];
		$jsonData = array('params'=>array(
			'standard_id'=>(int)$user_data['standard']
		)
		);
		$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
		$this->load->library('PHPRequests');
		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
		$response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
		$data=json_decode($response->body,true);//print_r($data);
		$datas=$data['result']; 
		foreach($datas as $subjects)
		{
			if($subject==$subjects['subject_id'])
			{
				$subject_name=$subjects['name'];
				break;
			}
		}
		$date=date_create($row['date']);
		$date=date_format($date,"F j, Y");
		$created_date=date_create($row['created_date']);
		$created_date=date_format($created_date,"F j, Y");
		$result=array('id'=>$row['id'],'subject'=>$subject_name,'description'=>$row['description'],'file'=>$row['file'],'due_date'=>$date,'created_date'=>$created_date);
		return $result;
	}
}

?>