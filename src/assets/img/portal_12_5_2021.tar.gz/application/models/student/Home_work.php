<?php
Class Home_work extends CI_model{
	function get_home_work($limit=1844674407)
	{
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];
		
		$query = $this->db->query("SELECT * FROM home_work WHERE standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' ORDER BY added_date LIMIT 0, $limit" );
		
		foreach ($query->result() as $row)
		{
			if (in_array($row->subject, $user_data['subject_ids'])) {
				$id=$row->id;
				$delivered=explode(',' ,$row->delivered_id);
				if (in_array($stu_id, $delivered))
				{
					
				}
				else
				{
					if($row->delivered_id!='')
					{
						$delivered_ids=$row->delivered_id.','.$stu_id;
					}
					else {
						$delivered_ids=$stu_id;
					}
					
					$this->db->query("UPDATE `home_work` SET `delivered_id`='$delivered_ids' WHERE `id`='$id'");
				}
				$query1 = $this->db->query("SELECT * FROM home_work_details WHERE home_work_id='$id' AND `student_id`='$stu_id'");
				if ($query1->num_rows()) 
				{
				$status='completed';
				} 
				else {
				$status='pending';
				}
				
				$row1=$query1->row_array();	
				$review_attachment=array();
				if($row1['review_attachment'])
				{
					$string = preg_replace('/\.$/', '', $row1['review_attachment']); //Remove dot at end if exists
					$array = explode(',', $row1['review_attachment']); //split string into array seperated by ', '
					foreach($array as $value) //loop over values
					{
						$qry=$this->db->query("SELECT * FROM home_work_attachments WHERE id='$value'");
						$rw=$qry->row_array();
						$review_attachment[]=array('id'=>$rw['id'],'name'=>$rw['name'],'type'=>$rw['type']);
					}
				}		
				$date=date_create($row->date);
				$date=date_format($date,"M j, Y");
				$addeddate=date_create($row->added_date);
				$addeddate=date_format($addeddate,"M j, Y");
				$adata[]=array('id'=>$row->id,'topic'=>$row->name,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'date'=>$date,'addeddate'=>$addeddate,'mark'=>$row1['mark'],'review'=>$row1['review'],'review_attachment'=>$review_attachment,'submit_status'=>$row1['status'],'status'=>$status);
			}
		}
		if(isset($adata))
		{
			return $adata;
		}
		else
		{
			return false;
		}
	}
	function getHomeworksList($page,$perPage,$type,$subject)
	{
		if(!$subject)
		{
			$subject=0;
		}
		$start = ($page - 1) * $perPage;
		$count=null;
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];
		$subjects=$user_data['subject_ids'];
	
		$subjects = implode("','",$subjects);
		$adata=array();
		if($page==1)
		{
			if($type=='pending')
			{
				$query = $this->db->query("SELECT id FROM home_work a WHERE `subject` IN ('$subjects') AND standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND('$subject' = 0 OR subject = $subject) AND NOT EXISTS ( SELECT * FROM home_work_details WHERE home_work_id = a.id AND `student_id`='$stu_id')");
			}
			else
			{
				$query = $this->db->query("SELECT id FROM home_work a WHERE `subject` IN ('$subjects') AND standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND('$subject' = 0 OR subject = $subject) AND EXISTS ( SELECT * FROM home_work_details WHERE home_work_id = a.id AND `student_id`='$stu_id')");
			}
			$count=$query->num_rows(); 
		}
		if($type=='pending')
		{
			$query = $this->db->query("SELECT * FROM home_work a WHERE `subject` IN ('$subjects') AND standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND('$subject' = 0 OR subject = $subject) AND NOT EXISTS ( SELECT * FROM home_work_details WHERE home_work_id = a.id AND `student_id`='$stu_id') ORDER BY added_date DESC LIMIT $start, $perPage");
		}
		else
		{
			$query = $this->db->query("SELECT * FROM home_work a WHERE `subject` IN ('$subjects') AND standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND('$subject' = 0 OR subject = $subject) AND EXISTS ( SELECT * FROM home_work_details WHERE home_work_id = a.id AND `student_id`='$stu_id') ORDER BY added_date DESC LIMIT $start, $perPage");
		}
		foreach ($query->result() as $row)
		{
			$id=$row->id;
			$delivered=explode(',' ,$row->delivered_id);
			if (in_array($stu_id, $delivered))
			{
				
			}
			else
			{
				if($row->delivered_id!='')
				{
					$delivered_ids=$row->delivered_id.','.$stu_id;
				}
				else {
					$delivered_ids=$stu_id;
				}
				
				$this->db->query("UPDATE `home_work` SET `delivered_id`='$delivered_ids' WHERE `id`='$id'");
			}	
			$addeddate=date_create($row->added_date);
			$addeddate=date_format($addeddate,"M j, Y");
			$review_attachment=array();
			$mark='';
			$review='';
			$submit_status='';
			if($type=='completed')
			{
				$query1 = $this->db->query("SELECT * FROM home_work_details WHERE home_work_id='$id' AND `student_id`='$stu_id'");
				
				$row1=$query1->row_array();	
				
				if($row1['review_attachment'])
				{
					$string = preg_replace('/\.$/', '', $row1['review_attachment']); //Remove dot at end if exists
					$array = explode(',', $row1['review_attachment']); //split string into array seperated by ', '
					foreach($array as $value) //loop over values
					{
						$qry=$this->db->query("SELECT * FROM home_work_attachments WHERE id='$value'");
						$rw=$qry->row_array();
						$review_attachment[]=array('id'=>$rw['id'],'name'=>$rw['name'],'type'=>$rw['type']);
					}
				}	
				
				$review=$row1['review'];
				$submit_status=$row1['status'];
			}
			$adata[]=array('id'=>$row->id,'topic'=>$row->name,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'date'=>$row->date,'addeddate'=>$addeddate,'review'=>$review,'review_attachment'=>$review_attachment,'submit_status'=>$submit_status);
		}
		echo json_encode(array('count'=>$count,'homeworks'=>$adata));
	}
	function get_calendar_home_work($month,$year)
	{
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$division=$user_data['division'];
		$stu_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];		
		$query = $this->db->query("SELECT * FROM home_work WHERE standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND MONTH(`date`)='$month' AND YEAR(`date`)='$year'");
		//echo "SELECT * FROM home_work WHERE standard='$standard' AND division='$division' AND acd_year='$acd_year' AND status='approved' AND MONTH(`date`)='$month' AND YEAR(`date`)='$year'";
		foreach ($query->result() as $row)
		{
			if (in_array($row->subject, $user_data['subject_ids'])) {
			
				$adata[]=array('id'=>$row->id,'topic'=>$row->name,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'date'=>$row->date,'addeddate'=>$row->added_date);
			}
		}
		if(isset($adata))
		{
			return $adata;
		}
		else
		{
			return false;
		}
	}
	function get_home_work_by_id($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$user_data=$this->session->userdata('loggedin');
		$standard=$user_data['standard'];
		$stu_id=$user_data['student_id'];
		$query=$this->db->query("SELECT * FROM home_work WHERE `id`='$id'");
		foreach ($query->result() as $row)
		{ 
			$read=explode(',' ,$row->read_id);
			if (in_array($stu_id, $read))
			{
				
			}
			else
			{
				if($row->read_id!='')
				{
					$read_ids=$row->read_id.','.$stu_id;
				}
				else {
					$read_ids=$stu_id;
				}
				
				$this->db->query("UPDATE `home_work` SET `read_id`='$read_ids' WHERE `id`='$id'");
			}
			$jsonData = array('params'=>array(
				'standard_id'=>(int)$standard
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $subjects)
			{
				if($subjects['subject_id']==$row->subject)
				{
					$subject=$subjects['name'];
				}
			}
			$date=date_create($row->date);
			$date=date_format($date,"M j, Y");
			$addeddate=date_create($row->added_date);
			$addeddate=date_format($addeddate,"M j, Y");
			$att=$row->attachment;
			$attachment=array();
			if($att!='')
			{
				$string = preg_replace('/\.$/', '', $att); //Remove dot at end if exists
				$array = explode(',', $att); //split string into array seperated by ', '
				foreach($array as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM home_work_attachments WHERE id='$value'");
					$rw=$qry->row_array();
					$attachment[]=array('id'=>$rw['id'],'name'=>$rw['name'],'type'=>$rw['type']);
				}
			}
			$answer_key=array();
			if($row->answer_key)
			{
				$string = preg_replace('/\.$/', '', $row->answer_key); //Remove dot at end if exists
				$array = explode(',', $row->answer_key); //split string into array seperated by ', '
				foreach($array as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM home_work_attachments WHERE id='$value'");
					$rw=$qry->row_array();
					$answer_key[]=array('id'=>$rw['id'],'name'=>$rw['name'],'type'=>$rw['type']);
				}
			}
			
			$stid=$user_data['student_id'];
			$mquery=$this->db->query("SELECT * FROM home_work_details WHERE student_id='$stid' AND home_work_id='$id'");
			if($mquery->num_rows()>0)
			{
				$mrow=$mquery->row_array();
				$mark_obt=$mrow['mark'];
				$submitted=TRUE;
				$desc=$mrow['description'];
				$submit_status=$mrow['status'];
				if($mrow['attachment']!='')
				{
					$att = preg_replace('/\.$/', '', $mrow['attachment']); //Remove dot at end if exists
					$atts = explode(',', $att); //split string into array seperated by ', '
					
					$attachments=array();
					foreach($atts as $value) //loop over values
					{
						$qry=$this->db->query("SELECT * FROM home_work_attachments WHERE id='$value'");
						$row1=$qry->row_array();
						$attachments[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
					}					
				}
				else{
					$attachments=array();
				}
				
			}
			else{
				$mark_obt='';
				$submitted=FALSE;
				$desc='';
				$attachments='';
				$submit_status='';
			}
			$adata[]=array('id'=>$row->id,'topic'=>$row->name,'course'=>(int)$row->course,'standard'=>(int)$row->standard,'division'=>(int)$row->division,'subject'=>$subject,'subject_id'=>(int)$row->subject,'date'=>$date,'addeddate'=>$addeddate,'description'=>$row->description,'marks'=>$row->marks,'attachment'=>$attachment,'answer_key'=>$answer_key,'mark_obt'=>$mark_obt,'submitted'=>$submitted,'desc'=>$desc,'atts'=>$attachments,'submit_status'=>$submit_status);
		}
		if(isset($adata))
		{
			return $adata;
		}
		else
		{
			return false;
		}
	}
	

	function submit_home_work($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$des=$this->db->escape_str(strip_tags($data->des));
		if(isset($data->att) && $data->att != "")
		{
			foreach($data->att as $att)
			{
				if(isset($attachment))
				{
					$attachment .=','.$att->id;
				}
				else
				{
					$attachment=$att->id;
				}
			}
		}
		else{
			$attachment='';
		}
		if(!isset($attachment))
		{
			$attachment='';
		}
		$user_data=$this->session->userdata('loggedin');
		$stu_id=$user_data['student_id'];
		$date=date('Y-m-d H:i:s');
		$query=$this->db->query("SELECT * FROM home_work_details WHERE home_work_id='$id' AND student_id='$stu_id'");
		$cnt=$query->num_rows();
		if($cnt>0)
		{
			if($this->db->query("UPDATE `home_work_details` SET  `description`='$des', `attachment`='$attachment', `submitted_date`='$date',`status`='pending' WHERE home_work_id='$id' AND student_id='$stu_id'"))
			{
				return true;
			}
		}
		else{
			if($this->db->query("INSERT INTO `home_work_details`(`home_work_id`, `student_id`, `description`, `attachment`, `submitted_date`) VALUES ('$id','$stu_id','$des','$attachment','$date')"))
			{
				$qry=$this->db->query("SELECT * FROM `home_work` WHERE `id`='$id'");
				$row=$qry->row_array();
				$delivered=explode(',' ,$row['delivered_id']);
				if (in_array($stu_id, $delivered))
				{
					$delivered_ids=$this->removeFromString($row['delivered_id'], $stu_id);
					$this->db->query("UPDATE `home_work` SET `delivered_id`='$delivered_ids' WHERE `id`='$id'");
				}
				$read=explode(',' ,$row['read_id']);
				if (in_array($stu_id, $read))
				{
					$read_ids=$this->removeFromString($row['read_id'], $stu_id);
					$this->db->query("UPDATE `home_work` SET `read_id`='$read_ids' WHERE `id`='$id'");
				}
				return true;
			}
		}
		
	}
	
	function get_asssignment_details($id){
		$sql = "SELECT `id`, `teacher_id`, `course`, `standard`, `division`, `subject`, `name`, `description`, `date`, `marks`, `attachment`, `added_date`, `acd_year` FROM `home_work` WHERE `id`= ?";
		$query = $this->db->query($sql, array($id));
		$row = $query->row_array();
		$home_work[] = array(
				'id' => $row['id'],
				'teacher_id' => $row['teacher_id'],
				'course' => $row['course'],
				"standard" => $row['standard'],
				"division" => $row['division'], 
				"subject" => $row['subject'], 
				"name" => $row['name'], 
				"description" => $row['description'], 
				"date" => $row['date'], 
				"marks" => $row['marks'], 
				"attachment" => $row['attachment'], 
				"added_date" => $row['added_date'], 
				"acd_year" => $row['acd_year']
		);
		return $home_work;
	}

	function removeFromString($str, $item) {
		$parts = explode(',', $str);
	
		while(($i = array_search($item, $parts)) !== false) {
			unset($parts[$i]);
		}
	
		return implode(',', $parts);
	}
}

?>