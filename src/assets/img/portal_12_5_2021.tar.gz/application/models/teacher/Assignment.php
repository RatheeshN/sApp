<?php
Class Assignment extends CI_model{
	function get_assignment()
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		//echo "SELECT * FROM assignment WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' ORDER BY `added_date` DESC";
		$query = $this->db->query("SELECT * FROM assignment WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' ORDER BY `added_date` DESC");	
		foreach ($query->result() as $row)
		{
			$answer_key=array();
			if($row->answer_key)
			{
				$answer=$row->answer_key;
				$answer = preg_replace('/\.$/', '', $answer); //Remove dot at end if exists
				$answer = explode(',', $answer); //split string into array seperated by ', '
				foreach($answer as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$answer_key[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			
				
			//$date=date_create($row->date);
			//$date=date_format($date,"M j, Y");
        	$notes=json_decode( $row->notes,true );
			$data[]=array('id'=>$row->id,'name'=>$row->name,'description'=>$row->description,'date'=>$row->date,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'status'=>$row->status,'notes'=>$notes,'answer_key'=>$answer_key);
			
		}
		if(isset($data))
		{
			return $data;
		}
	}
	function getAssignmentsList($postdata)
	{
		$postdata->course?$course=$postdata->course:$course=0;
		$postdata->standard?$standard=$postdata->standard:$standard=0;
		$postdata->division?$division=$postdata->division:$division=0;
		$postdata->subject?$subject=$postdata->subject:$subject=0;
		$postdata->date?$date=date('Y-m-d',strtotime(str_replace('/','-',$postdata->date))):$date='0000-00-00 00:00:00';
		$postdata->search?$search=$postdata->search:$search='';
		$start = ($postdata->page - 1) * $postdata->perPage;
		$count=null;
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=array();
		if($postdata->page==1)
		{
			$query = $this->db->query("SELECT * FROM assignment WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' AND('$course' = 0 OR course = $course) AND('$standard' = 0 OR standard = $standard) AND('$division' = 0 OR division = $division) AND('$subject' = 0 OR subject = $subject) AND('$date' = 0 OR DATE(added_date) = '$date') AND(name LIKE '%$search%')");
			$count=$query->num_rows();
		}
		$query = $this->db->query("SELECT * FROM assignment WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' AND('$course' = 0 OR course = $course) AND('$standard' = 0 OR standard = $standard) AND('$division' = 0 OR division = $division) AND('$subject' = 0 OR subject = $subject) AND('$date' = 0 OR DATE(added_date) = '$date') AND(name LIKE '%$search%') ORDER BY `added_date` DESC LIMIT $start, $postdata->perPage");
		foreach ($query->result() as $row)
		{
			$answer_key=array();
			if($row->answer_key)
			{
				$answer=$row->answer_key;
				$answer = preg_replace('/\.$/', '', $answer); //Remove dot at end if exists
				$answer = explode(',', $answer); //split string into array seperated by ', '
				foreach($answer as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$answer_key[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			$notes=json_decode( $row->notes,true );
			$date=date_create($row->added_date);
			$date=date_format($date,"M j, Y");
			
			$data[]=array('id'=>$row->id,'name'=>$row->name,'description'=>$row->description,'date'=>$date,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'status'=>$row->status,'notes'=>$notes,'answer_key'=>$answer_key);			
		}
		return array('assignments'=>$data,'count'=>$count);			
	}
	function get_single_assignment($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$query = $this->db->query("SELECT * FROM assignment WHERE teacher_id='$teacher_id' AND id='$id' ");	
		foreach ($query->result() as $row)
		{
			$attachment=array();
			if($row->attachment)
			{
				$att=$row->attachment;
				$att = preg_replace('/\.$/', '', $att); //Remove dot at end if exists
				$atts = explode(',', $att); //split string into array seperated by ', '				
				foreach($atts as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$attachment[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			$answer_key=array();
			if($row->answer_key)
			{
				$answer=$row->answer_key;
				$answer = preg_replace('/\.$/', '', $answer); //Remove dot at end if exists
				$answer = explode(',', $answer); //split string into array seperated by ', '
				foreach($answer as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$answer_key[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			
			$date=date_create($row->date);
			$date=date_format($date,"M j, Y");
			$created_date=date_create($row->added_date);
			$created_date=date_format($created_date,"M j, Y");	
			$data[]=array('id'=>$row->id,'course'=>(int)$row->course,'standard'=>(int)$row->standard,'division'=>(int)$row->division,'subject'=>(int)$row->subject,'marks'=>$row->marks,'name'=>$row->name,'description'=>$row->description,'date'=>$date,'attachment'=>$attachment,'answer_key'=>$answer_key,'created_date'=>$created_date);
		}
		if(isset($data))
		{
			return $data;
		}
		else
		{
			return false;
		}
	}
	function get_students($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT * FROM assignment WHERE id='$id'");
		$sdatas=array();
		foreach ($query->result() as $row)
		{
			$assignment_name=$row->name;
			$max_mark=$row->marks;
			$read=explode(',',$row->read_id);
			$delivered=explode(',',$row->delivered_id);
			$jsonData = array('params'=>array(
				'standard_id'   =>(int)$row->standard,
				'division_id'   =>(int)$row->division,
				'subject_id'    =>(int)$row->subject
				)
			); //http://localhost:8075/lms/dataset/getStudentsByStandardDivisionSuAbject
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'/lms/dataset/getStudentsByStandardDivisionSubject',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);//print_r($data);
			$datas=$data['result']; 
			foreach ($datas as $sdata)
			{
				
				$sid=$sdata['id'];
				$aquery=$this->db->query("SELECT * FROM assignment_details WHERE student_id='$sid' AND assignment_id='$id'");
				$attachment=array();
				$review_attachment=array();
				//echo $aquery->num_rows();
				if($aquery->num_rows())
				{
					foreach ($aquery->result() as $arow)
					{ 
						$date=date_create($arow->submitted_date);
						$date=date_format($date,"M j, Y");
						$status='completed';
						$mark=$arow->mark;
						$description=$arow->description;
						$submit_status=$arow->status;
						//$attachment=$arow->attachment;
						$review=$arow->review;
						if(isset($arow->attachment) && $arow->attachment!='')
						{
							$array = explode(',', $arow->attachment); //split string into array seperated by ', '
							foreach($array as $value) //loop over values
							{
								$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
								$row1=$qry->row_array();
								$attachment[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
							}
						}
						else{
							$attachment='';
						}
						
						if(isset($arow->review_attachment) && $arow->review_attachment!='')
						{
							$array = explode(',', $arow->review_attachment); //split string into array seperated by ', '
							foreach($array as $value) //loop over values
							{
								$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
								$row1=$qry->row_array();
								$review_attachment[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
							}
						}
						
					}
				}
				else
				{
					$date='';
					$status='pending';
					$mark='';
					$description='';
					$attachment='';
					$review='';
					$submit_status='';
					if (in_array($sid, $delivered)) {
						$status = "delivered";
					}
					if (in_array($sid, $read)) {
						$status = "read";
					}
					

				}
				$sdatas[]=array('id'=>$id,'sid'=>$sid,'assignment_name'=>$assignment_name,'max_mark'=>$max_mark,'name'=>$sdata['name'],'submitted_date'=>$date,'mark'=>$mark,'description'=>$description,'attachment'=>$attachment,'review'=>$review,'review_attachment'=>$review_attachment,'status'=>$status,'submit_status'=>$submit_status);
			}
		}
		return $sdatas;
	}
	public function add_assignment($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);		
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$subject=$data->subject;
		$name=$this->db->escape_str($data->name);
		$description=$this->db->escape_str($data->description);
		$date=$data->date;
		$mark=$data->mark;
		$date=date("Y-m-d",strtotime(str_replace('/', '-',$data->date)));
		$user_data=$this->session->userdata('loggedin');
    
		if(isset($data->attachment))
		{
			
			foreach($data->attachment as $att)
			{
				if(isset($attachment))
				{
					$attachment .=','.$att->id;
				}
				else
				{
					$attachment=$att->id;
				}
			}
		}
		else{
			$attachment='';
		}
		if(!isset($attachment))
		{
			$attachment='';
		}

		if(isset($data->answer_key))
		{
			
			foreach($data->answer_key as $ans)
			{
				if(isset($answer_key))
				{
					$answer_key .=','.$ans->id;
				}
				else
				{
					$answer_key=$ans->id;
				}
			}
		}
		else{
			$answer_key='';
		}
		if(!isset($answer_key))
		{
			$answer_key='';
		}
		
		$added_date=date('Y-m-d H:i:s');
     	$teacher_config=$this->conf->faculty;
		if($teacher_config->fc_assignment_approval=='1')
        {
        	$query = $this->db->query("INSERT INTO `assignment`(`teacher_id`, `course`, `standard`, `division`, `subject`, `name`, `description`, `date`, `marks`, `attachment`, `answer_key`,`added_date`,`acd_year`,`status`) VALUES ('$teacher_id','$course','$standard','$division','$subject','$name','$description','$date','$mark','$attachment','$answer_key','$added_date','$acd_year','pending')");
        }
    	else
        {
        	$query = $this->db->query("INSERT INTO `assignment`(`teacher_id`, `course`, `standard`, `division`, `subject`, `name`, `description`, `date`, `marks`, `attachment`,`answer_key`, `added_date`,`acd_year`,`status`) VALUES ('$teacher_id','$course','$standard','$division','$subject','$name','$description','$date','$mark','$attachment','$answer_key','$added_date','$acd_year','approved')");
        }
		if($query)
		{
			$id=$this->db->insert_id();
			$url='#/assignment/'.$id;
			$this->db->query("INSERT INTO `student_notifications`( `standard_id`, `division_id`, `module`, `item_id`, `url`, `message`, `date`) VALUES ('$standard',$division,'assignment','$id','$url','You have a new Assignment','$added_date')");
        
        	$assignment_id=$this->db->insert_id();
        	$jsonData = array('params'=>array(
			'standard_id'    =>(int)$standard,
			'division_id'    =>(int)$division
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {
            	
            	if($teacher_config->fc_assignment_approval!='1')
        		{
					$data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>"Dear Parent, You have a new Assignment.", 'type'=>'assignment','sound'=>"common_alert.wav");
					$jsonData = array(
					'student_id'    =>$student['id'],
					"data"=>$data_content
					);
					$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
					$this->load->library('PHPRequests');
					$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
					$response = Requests::post(API_PATH.'api_v2/notification/send_student_push_notification',$headers,$jsonDataEncoded);
					
					$data=json_decode($response->body,true);
				}
            }
			
			return $data=array('status'=>'success','msg'=>'Assignment Published Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Publishing Assignment');			
		}
	}

	function assignment_edit($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);
		$id=$data->id;
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$subject=$data->subject;
		$name=$this->db->escape_str($data->name);
		$description=$this->db->escape_str($data->description);
		$mark=$data->mark;
		$date=date("Y-m-d",strtotime(str_replace('/', '-',$data->date)));
		$description=$data->description;
		
		if(isset($data->attachment))
		{
			$qry=$this->db->query("SELECT `attachment` FROM `assignment` WHERE `id`='$id'");
			$at_row=$qry->row_array();
			$at_row['attachment'];
			$existing_ids=$at_row['attachment'];
			$existing_ids=explode(',',$existing_ids);
			foreach($data->attachment as $att)
			{
				
				if(isset($attachment))
				{
					$attachment .=','.$att->id;
				}
				else
				{
					$attachment=$att->id;
				}
			}
			$current_ids=explode(',',$attachment);
			foreach($existing_ids as $existing)
			{
				if(!in_array($existing, $current_ids))
				{
					$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$existing'");
					$row=$at_qry->row_array();
					$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
					if(file_exists($file))
					unlink($file);
					$this->db->query("DELETE FROM assignment_attachments WHERE id='$existing'");
				}
			}
		}
		else{
			$attachment='';
			$qry=$this->db->query("SELECT `attachment` FROM `assignment` WHERE `id`='$id'");
			$at_row=$qry->row_array();
			$at_row['attachment'];
			$existing_ids=$at_row['attachment'];
			$existing_ids=explode(',',$existing_ids);
			foreach($existing_ids as $existing)
			{
				$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$existing'");
				$row=$at_qry->row_array();
				$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
				if(file_exists($file))
				unlink($file);
				$this->db->query("DELETE FROM assignment_attachments WHERE id='$existing'");
			}
		}
		if(isset($data->new_attachments))
		{
			foreach($data->new_attachments as $atts)
			{				
				if(isset($attachments))
				{
					$attachments .=','.$atts->id;
				}
				else
				{
					$attachments=$atts->id;
				}
			}
		}
		if(isset($attachments))
		{
			$attachment=$attachment.','.$attachments;
		}



		if(isset($data->answer_key))
		{
			
			foreach($data->answer_key as $ans)
			{
				if(isset($answer_key))
				{
					$answer_key .=','.$ans->id;
				}
				else
				{
					$answer_key=$ans->id;
				}
			}
		}
		else{
			$answer_key='';
		}
		if(!isset($answer_key))
		{
			$answer_key='';
		}


		$added_date=date('Y-m-d H:i:s');
    $teacher_config=$this->conf->faculty;
   
		if($teacher_config->fc_assignment_approval=='1')
        {
        	$query = $this->db->query("UPDATE `assignment` SET `teacher_id`='$teacher_id', `course`='$course', `standard`='$standard', `division`='$division', `subject`='$subject', `name`='$name', `description`='$description', `date`='$date', `marks`='$mark', `attachment`='$attachment',`answer_key`='$answer_key',`status`='pending' WHERE id='$id'"); 
        }
    	else
        {
        	$query = $this->db->query("UPDATE `assignment` SET `teacher_id`='$teacher_id', `course`='$course', `standard`='$standard', `division`='$division', `subject`='$subject', `name`='$name', `description`='$description', `date`='$date', `marks`='$mark', `attachment`='$attachment',`answer_key`='$answer_key',`status`='approved' WHERE id='$id'");
        }
		if($query)
		{
			return $data=array('status'=>'success','msg'=>'Assignment Updated Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Updating Assignment');			
		}
	}
	
	function submit_assignment_review($postdata)
	{
		$data=json_decode($postdata);
		$asid=$data->asid;
		$sid=$data->sid;
		$mark=$data->mark;
		$review=$this->db->escape_str($data->review);
		$status=$data->status;
		if(isset($data->review_attachment))
		{
			
			foreach($data->review_attachment as $att)
			{
				if(isset($review_attachment))
				{
					$review_attachment .=','.$att->id;
				}
				else
				{
					$review_attachment=$att->id;
				}
			}
		}
		else{
			$review_attachment='';
		}
		if(!isset($review_attachment))
		{
			$review_attachment='';
		}
		if($this->db->query("UPDATE assignment_details SET `mark`='$mark',`review`='$review',`review_attachment`='$review_attachment',`status`='$status' WHERE assignment_id='$asid' AND student_id='$sid'"))
		{
			return true;
		}
	}

	function delete_assignment($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT attachment FROM assignment WHERE id='$id'");
		$row=$query->row_array();
		if($row['attachment']!='')
		{
			$attachments=explode(',',$row['attachment']);
			foreach($attachments as $atts)
			{
				$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$atts'");
				$row=$at_qry->row_array();
				$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
				if(file_exists($file))
				unlink($file);
				$this->db->query("DELETE FROM assignment_attachments WHERE id='$atts'");
			}
		}
		if($this->db->query("DELETE FROM assignment WHERE id='$id'"))
		{
			$this->db->query("DELETE FROM assignment_details WHERE assignment_id='$id'");
			return $data=array('status'=>'success','msg'=>'Assignment Deleted Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Deleting Assignment');
		}
	}

	function add_key($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$new_keys=$data->keys[0]->id;
		$qry=$this->db->query("SELECT `answer_key` FROM `assignment` WHERE `id`='$id'");
		$row=$qry->row_array();
		if($row['answer_key'])
		{
			$new_keys=$row['answer_key'].','.$new_keys;
		}
		$qry=$this->db->query("UPDATE `assignment` SET `answer_key`='$new_keys' WHERE `id`='$id'");
		if($qry)
		{
			return $data=array('status'=>'success','msg'=>'Key Added Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error adding key');	
		}
	}

	function remove_assign_key($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$asid=$data->asid;
		
		$qry=$this->db->query("SELECT `answer_key` FROM `assignment` WHERE `id`='$asid'");
		$row=$qry->row_array();
		if($row['answer_key'])
		{
			$parts = explode(',', $row['answer_key']);
			while(($i = array_search($id, $parts)) !== false) {
				unset($parts[$i]);
			}
			$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$id'");
			$row1=$at_qry->row_array();
			$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row1['name'];
			if(file_exists($file))
			unlink($file);
			$new_keys= implode(',',$parts);//print_r($new_keys);
		}
		else
		{
			$new_keys=$id;
		}
		$qry=$this->db->query("UPDATE `assignment` SET `answer_key`='$new_keys' WHERE `id`='$asid'");
		if($qry)
		{
			return $data=array('status'=>'success','msg'=>'Key Removed Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error removing key');	
		}
	}
}

?>