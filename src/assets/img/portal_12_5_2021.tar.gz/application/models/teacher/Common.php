<?php
Class Common extends CI_model{
	function get_courses()
	{
		$user_data=$this->session->userdata('loggedin');
		//$standard=$user_data['standard'];
		//$division=$user_data['division'];
		$teacher_id=1;
		$query = $this->db->query("SELECT * FROM todo WHERE teacher_id='1'");
		
		foreach ($query->result() as $row)
		{
			$date=date_create($row->date);
			$date=date_format($date,"F j, Y");
			$data[]=array('id'=>$row->id,'topic'=>$row->topic,'description'=>$row->description,'date'=>$date);
		}
		if(isset($data))
		{
			return $data;
		}
		else
		{
			return false;
		}
	}
}

?>