<?php

Class Notifications extends CI_model{
    function get_notifications()
    {
        $user_data = $this->session->userdata('loggedin');
        $teacher_id =  $user_data["uid"];

        $sql = "SELECT `id`, `teacher_id`, `module`, `item_id`, `message`, CONCAT('#/', module, '/', item_id) AS url, `seen_status`, `read_status`, `create_time` FROM `teacher_notifications` WHERE `teacher_id`= ? ORDER BY `id` desc;";
		
		$query = $this->db->query($sql, array($teacher_id));
		$result = $query->result();
        
        for($i = 0; $i < count($result); $i++){
            $result[$i]->module = ucfirst($result[$i]->module);
        }

		return $result;
    }

    function make_all_seen(){
        $user_data = $this->session->userdata('loggedin');
        $teacher_id =  $user_data["uid"];

        $sql = "update teacher_notifications set seen_status = 1 where teacher_id=?";
        $result = $this->db->query($sql, array($teacher_id));
		return $result;
    }

    function get_new_notifications($postdata)
    {
        $postdata = json_decode($postdata);
        $id = $postdata->id;
        $user_data = $this->session->userdata('loggedin');
		$teacher_id = $user_data['uid'];
		
		$sql = "SELECT `id`, `teacher_id`, `module`, `item_id`, `message`, CONCAT('#/', module, '/', item_id) AS url, `seen_status`, `read_status`, `create_time` FROM `teacher_notifications` WHERE `teacher_id`= ? AND `id` > ?  ORDER BY `create_time` desc;";
		
		$query = $this->db->query($sql, array($teacher_id, $id));
		$result = $query->result();
        
        for($i = 0; $i < count($result); $i++){
            $result[$i]->module = ucfirst($result[$i]->module);
        }

		return $result;
	}

    function get_all_notifications($postdata)
    {
        $postdata = json_decode($postdata);
        $start = $postdata->start;
        $limit = $postdata->limit;

        $user_data = $this->session->userdata('loggedin');
		$teacher_id = $user_data['uid'];
		
		$sql = "SELECT `id`, `teacher_id`, `module`, `item_id`, `message`, CONCAT('#/', module, '/', item_id) AS url, `seen_status`, `read_status`, `create_time` FROM `teacher_notifications` WHERE `teacher_id`= ?  ORDER BY `id` desc limit $start, $limit";
		
		$query = $this->db->query($sql, array($teacher_id));
        $result = $query->result();
        
        for($i = 0; $i < count($result); $i++){
            $result[$i]->module = ucfirst($result[$i]->module);
        }
		
		return $result;
    }
}

?>