<?php
Class Todo extends CI_model{
	function get_todo()
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
	
		$query = $this->db->query("SELECT * FROM todo WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' ORDER BY `date` DESC");
		
		foreach ($query->result() as $row)
		{
			$date=date_create($row->date);
			$date=date_format($date,"d/m/Y");
        	$notes=json_decode( $row->notes,true );
        	$files= explode (",", $row->file);  
			$data[]=array('id'=>$row->id,'topic'=>$row->topic,'description'=>$row->description,'date'=>$date,'course'=>$row->course_id,'standard'=>$row->standard_id,'division'=>$row->division_id,'subject'=>$row->topic,'file'=>$files,'status'=>$row->status,'notes'=>$notes);
		}
		if(isset($data))
		{
			return $data;
		}
		else
		{
			return false;
		}
	}
	public function get_single_todo($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
	
		$query = $this->db->query("SELECT * FROM todo WHERE teacher_id='$teacher_id' AND acd_year='$acd_year' AND id='$id'");
		return $result= $query->row_array();
	}
	public function add_todo($postdata)
	{
		//print_r($_FILES['file']['name']);
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		
		// $course=$_POST['course'];
		// $standard=$_POST['standard'];
		// $division=$_POST['division'];
		// $topic=$_POST['topic'];
		// $date=date("Y-m-d",strtotime($_POST['date']));
		// $description=$_POST['description'];
		// $added_date=date('Y-m-d H:i:s');
    
    	$data=json_decode($postdata);
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$topic=$data->topic;
		$date=date("Y-m-d",strtotime($data->date));
		$description=$data->description;
		$added_date=date('Y-m-d H:i:s');
		
		$att=$data->attachment;
    	$file = implode(',', $att); 
		if($this->conf->faculty->fc_todo_approval=='1')
		{
			$query = $this->db->query("INSERT INTO `todo`( `teacher_id`, `course_id`, `standard_id`, `division_id`, `topic`, `description` ,`file` , `date`,`created_date`,`acd_year`,`status`) VALUES ('$teacher_id','$course','$standard','$division','$topic','$description','$file','$date','$added_date','$acd_year','pending')");
		}
		else
		{
			$query = $this->db->query("INSERT INTO `todo`( `teacher_id`, `course_id`, `standard_id`, `division_id`, `topic`, `description` ,`file` , `date`,`created_date`,`acd_year`,`status`) VALUES ('$teacher_id','$course','$standard','$division','$topic','$description','$file','$date','$added_date','$acd_year','approved')");
		}
		if($query)
		{
			$id=$this->db->insert_id();
			$url='#/todo/'.$id;
			$this->db->query("INSERT INTO `student_notifications`( `standard_id`, `division_id`, `module`, `item_id`, `url`, `message`, `date`) VALUES ('$standard',$division,'todo','$id','$url','You have a new Todo Task','$added_date')");
        
        	$todo_id=$this->db->insert_id();
        	$jsonData = array('params'=>array(
			'standard_id'    =>(int)$standard,
			'division_id'    =>(int)$division
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {
                $student['id'];           

            	$data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>"Dear Parent, You have a new Home Work", 'type'=>'todo','sound'=>"common_alert.wav");
            	
            	$jsonData = array(
				'student_id'    =>$student['id'],
                "data"=>$data_content
				);
				$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
				$this->load->library('PHPRequests');
        		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
				$response = Requests::post(API_PATH.'api_v1/notification/send_student_push_notification',$headers,$jsonDataEncoded);
           
				$data=json_decode($response->body,true);
            }
			return $data=array('status'=>'success','msg'=>'Home Work Added Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Adding Home Work');		
		}
	}

	public function show_todo_status($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT * FROM `todo` WHERE `id`='$id'");
		$row=$query->row_array();
		$standard_id=$row['standard_id'];
		$division_id=$row['division_id'];
		$completed=$row['completed_id'];
		$completed = explode(',',$completed);
		$delivered=$row['delivered_id'];
		$delivered = explode(',',$delivered);
		$read=$row['read_id'];
		$read = explode(',',$read);
		
		$user_data=$this->session->userdata('loggedin');
		$jsonData = array('params'=>array(
			'standard_id'=>(int)$standard_id,
			'division_id'=>(int)$division_id
		)
		);
		$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
		$this->load->library('PHPRequests');
		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
		$response = Requests::post(API_PATH.'/lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
		$data=json_decode($response->body,true);
		$data=$data['result'];
		$list=array();
		foreach($data as $student)
		{
			
			if (in_array($student['id'], $completed)) {
				$status = "Completed";
			}
			else if (in_array($student['id'], $read)) {
				$status = "Read";
			}
			else if (in_array($student['id'], $delivered)) {
				$status = "Delivered";
			}
			else {
				$status= "Pending";
			}
			$list[]=array('id'=>$student['id'],'roll_no'=>$student['roll_number'],'name'=>$student['name'],'status'=>$status);
		}
		return $list;
		
	}
	public function delete_todo($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("DELETE FROM `todo` WHERE `id`='$id'");
		if($query)
		{
			return $data=array('status'=>'success','msg'=>'Homework Deleted Successfully');
		}
		else {
			return $data=array('status'=>'error','msg'=>'Error Deleting Homework');
		}
	}


	public function update_todo($postdata)
	{
		//print_r($_FILES['file']['name']);
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$topic=$data->topic;
		$date=date("Y-m-d",strtotime($data->date));
		$description=$data->description;
		$added_date=date('Y-m-d H:i:s');
		
		$id=$data->id;;

		$att=$data->attachment;
    	$file = implode(',', $att); 
    
		if($this->db->query("UPDATE `todo` SET `teacher_id`='$teacher_id', `course_id`='$course', `standard_id`='$standard', `division_id`='$division', `topic`='$topic', `description`='$description' ,`file`='$file' , `date`='$date' WHERE id='$id'"))
		{
			return $data=array('status'=>'success','msg'=>'Homework Updated Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Updating Homework');		
		}
	}
}

?>