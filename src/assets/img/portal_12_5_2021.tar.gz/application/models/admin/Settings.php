<?php
Class Settings extends CI_model{

    public function get_admin_settings()
    {
        $conf_qry=$this->db->query("SELECT * FROM `admin_settings` WHERE `id`=1");
		$conf_row=$conf_qry->row_array();
        return json_decode($conf_row['settings']);
    }
    public function update_admin_settings($settings)
    {
        $settings=json_encode($settings);
        $qry=$this->db->query("UPDATE `admin_settings` SET `settings`='$settings' WHERE `id`=1");
        if($qry)
        {
            return true;
        }
    }
}
?>