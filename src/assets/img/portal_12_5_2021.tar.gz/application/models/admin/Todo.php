<?php
Class Todo extends CI_model{
	function todo_list($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$acd_year=$user_data['acd_year'];
		$todos=array();
		$where=array();
		if(isset($postdata->date))
		{
			$postdata->date=date("Y-m-d",strtotime($postdata->date));
			$date=array('date(created_date)'=>$postdata->date);
			$where=array_merge($where, $date);
		}
		
		if(isset($postdata->standard))
		{
			$standard=array('standard_id'=>$postdata->standard);
			$where=array_merge($where, $standard);
		}
		if(isset($postdata->division))
		{
			$division=array('division_id'=>$postdata->division);
			$where=array_merge($where, $division);
		}
		if(isset($postdata->course))
		{
			$course=array('course_id'=>$postdata->course);
			$where=array_merge($where, $course);
		}	
		if(isset($postdata->teacher))
		{
			$teacher=array('teacher_id'=>$postdata->teacher);
			$where=array_merge($where, $teacher);
		}	
		//print_r($where);
		// $standard=$postdata->standard;
		// $division=$postdata->division;
		// $course=$postdata->course;
		$query = $this->db->get_where('todo', $where);
		
		$data=array();
		foreach ($query->result() as $row)
		{
			$course=$row->course_id;
			$standard=$row->standard_id;
			$division=$row->division_id;
			$teacher=$row->teacher_id;
			$subject=$row->topic;
			

			$jsonData = array('params'=>array(
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getTeachersList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $teachers)
			{
				if($teacher==$teachers['user_id'])
				{
					$teacher_name=$teachers['name'];
					break;
				}
			}
			$date=date_create($row->date);
			$date=date_format($date,"F j, Y");
			$created_date=date_create($row->created_date);
			$created_date=date_format($created_date,"F j, Y");
			$todos[]=array('id'=>$row->id,'teacher'=>$teacher_name,'description'=>$row->description,'date'=>$date,'created_date'=>$created_date);
		}
		if(isset($todos))
		{
			return $todos;
		}
		
	}
	
	public function get_single_todo($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$user_data=$this->session->userdata('loggedin');
		
		$todo=array();
		$query = $this->db->query("SELECT * FROM todo WHERE id='$id' ");	
		foreach ($query->result() as $row)
		{
			$course=$row->course_id;
			$standard=$row->standard_id;
			$division=$row->division_id;
			$teacher=$row->teacher_id;
			$subject=$row->topic;
			

			$jsonData = array('params'=>array(
				'course_id'=>(int)$course
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStandardList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $standards)
			{
				if($standard==$standards['standard_id'])
				{
					$standard_name=$standards['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
				'standard_id' => (int)$standard
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getDivisionList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $divisions)
			{
				if($division==$divisions['division_id'])
				{
					$division_name=$divisions['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
				'standard_id'=>(int)$standard
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $subjects)
			{
				if($subject==$subjects['subject_id'])
				{
					$subject_name=$subjects['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getTeachersList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $teachers)
			{
				if($teacher==$teachers['user_id'])
				{
					$teacher_name=$teachers['name'];
					break;
				}
			}
			$date=date_create($row->date);
			$date=date_format($date,"F j, Y");
			$created_date=date_create($row->created_date);
			$created_date=date_format($created_date,"F j, Y");
			$todo[]=array('id'=>$row->id,'standard'=>$standard_name,'division'=>$division_name,'subject'=>$subject_name,'teacher'=>$teacher_name,'description'=>$row->description,'date'=>$date,'created_date'=>$created_date,'attachment'=>$row->file);
			return $todo;
		}
	}
	public function add_todo($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$topic=$data->topic;
		$date=date("Y-m-d",strtotime($data->date));
		$description=$data->description;
		if($query = $this->db->query("INSERT INTO `todo`( `teacher_id`, `course_id`, `standard_id`, `division_id`, `topic`, `description`, `date`,`acd_year`) VALUES ('$teacher_id','$course','$standard','$division','$topic','$description','$date','$acd_year')"))
		{
			return $data=array('status'=>'success','msg'=>'Todo Added Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Adding Todo');			
		}
	}

	public function show_todo_status($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT * FROM `todo` WHERE `id`='$id'");
		$row=$query->row_array();
		$standard_id=$row['standard_id'];
		$division_id=$row['division_id'];
		$completed=$row['completed_id'];
		$completed = explode(',',$completed);
		$user_data=$this->session->userdata('loggedin');
		$jsonData = array('params'=>array(
			'standard_id'=>(int)$standard_id,
			'division_id'=>(int)$division_id
		)
		);
		$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
		$this->load->library('PHPRequests');
		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
		$response = Requests::post(API_PATH.'/lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
		$data=json_decode($response->body,true);
		$data=$data['result'];
		$list=array();
		foreach($data as $student)
		{
			if (in_array($student['id'], $completed)) {
				$status = "Completed";
			} else {
				$status= "Pending";
			}
			$list[]=array('id'=>$student['id'],'roll_no'=>$student['roll_number'],'name'=>$student['name'],'status'=>$status);
		}
		return $list;
		
	}


	function get_todo()
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=array();
		$query = $this->db->query("SELECT * FROM todo WHERE `acd_year`='$acd_year' AND `status`='pending' ORDER BY `date` DESC");	
		foreach ($query->result() as $row)
		{
			
			$due_date=date_create($row->date);
			$due_date=date_format($due_date,"F j, Y");
        	$created_date=date_create($row->created_date);
			$created_date=date_format($created_date,"F j, Y");
			$data[]=array('id'=>$row->id,'description'=>$row->description,'due_date'=>$due_date,'created_date'=>$created_date);
		}
		return $data;
		
	}
	function approve_todo($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$query=$this->db->query("UPDATE todo SET `status`='approved'  WHERE id='$id'");
		if($query)
		{
			
			return $data=array('status'=>'success','msg'=>'Homework Approved Successfully');
			
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
			
		}
	}

	function send_todo_notification($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		
		$qry=$this->db->query("SELECT * FROM todo WHERE id='$id'");
		$row=$qry->row_array();
    	$user_data=$this->session->userdata('loggedin');
		$jsonData = array('params'=>array(
			'standard_id'    =>(int)$row['standard'],
			'division_id'    =>(int)$row['division']
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {
                $data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>"You have a new Homework.", 'type'=>'todo','sound'=>"common_alert.wav");
            	$jsonData = array(
				'student_id'    =>$student['id'],
                "data"=>$data_content
				);
				$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
				$this->load->library('PHPRequests');
        		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
				$response = Requests::post(API_PATH.'staging-api/notification/send_student_push_notification',$headers,$jsonDataEncoded);
				$data=json_decode($response->body,true);print_r($data);
			}
	}
	function reject_todo($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$date=date('Y-m-d H:i:s');
		$qry=$this->db->query("SELECT * FROM todo WHERE id='$id'");
		$row=$qry->row_array();
		$note=$row['notes'];
		$note=json_decode($note,true);
		$note[]=array('date'=>$date,'note'=>$postdata->note);
		$note=json_encode($note);

		$query=$this->db->query("UPDATE todo SET `notes`='$note', `status`='rejected'  WHERE id='$id'");
		
		if($query)
		{			
			return $data=array('status'=>'success','msg'=>'Todo Rejected');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
		}
	}

	function approve_multiple_todo($postdata)
	{
		$postdata=json_decode($postdata);
		//$ids=$postdata->id;
		$error='0';
		foreach($postdata as $id )
		{
			if($this->db->query("UPDATE todo SET `status`='approved'  WHERE id='$id'"))
			{
				$error='0';
			}
			else
			{
				$error='1';
			}
		}
		
		
		if($error=='0')
		{
			
			return $data=array('status'=>'success','msg'=>'Todo Approved Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
		}
	}

	function send_multiple_notification($postdata)
	{
		$postdata=json_decode($postdata);
		//$ids=$postdata->id;
		
		foreach($postdata as $id )
		{
			

			$qry=$this->db->query("SELECT * FROM todo WHERE id='$id'");
			$row=$qry->row_array();
    		$user_data=$this->session->userdata('loggedin');
			$jsonData = array('params'=>array(
			'standard_id'    =>(int)$row['standard'],
			'division_id'    =>(int)$row['division']
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {
            	
                $data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>" You have a new Todo.", 'type'=>'todo','sound'=>"common_alert.wav");
            	$jsonData = array(
				'student_id'    =>$student['id'],
                "data"=>$data_content
				);
				$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
				$this->load->library('PHPRequests');
        		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
				$response = Requests::post(API_PATH.'staging-api/notification/send_student_push_notification',$headers,$jsonDataEncoded);
           		
				$data=json_decode($response->body,true);print_r($data);
			}
		}
		
	}
}

?>