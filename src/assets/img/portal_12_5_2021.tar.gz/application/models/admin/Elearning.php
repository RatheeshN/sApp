<?php
Class Elearning extends CI_model{
	
	function get_chapter_topic($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$data=json_decode($postdata);
		$standard_id=$data->standard_id;
		$standard=$data->standard;
		$subject_id=$data->subject_id;
		$subject=$data->subject;
		
		$query = $this->db->query("SELECT * FROM elearning_topics WHERE standard_id='$standard_id' AND standard='$standard' AND subject_id='$subject_id' AND subject='$subject' ORDER BY id ASC");	
		foreach ($query->result() as $row)
		{	
			if($row->parent=='0')
			{
				$parent=null;
			}
			else
			{
				$parent=$row->parent;
			}
			$tdata[]=array('id'=>$row->id,'name'=>$row->name,'parent_id'=>$row->parent,'type'=>$row->type,'added'=>'');
		}
		
		if(isset($tdata))
		{
			$fdata=$this->buildTree($tdata);
		}
		if(isset($fdata))
		{
			return $fdata;
		}
		else
		{
			return false;
		}
	}

	public function update_topics($postdata)
	{//print_r($postdata);
		$data=json_decode($postdata,TRUE);
		$topics=$data['data'];
		$standard_id=$data['standard_id'];
		$standard=$data['standard'];
		$subject_id=$data['subject_id'];
		$subject=$data['subject'];
		$added_date=date('Y-m-d H:i:s');
		
		$result = [];
		array_walk_recursive($topics, function($v, $k) use (&$result){  
			if ($k == 'id') $result[] = ['id'=> $v];
			if ($k == 'name') {
				$result[count($result)-1]['name'] = $v;
			}
			if ($k == 'parent_id') {
				$result[count($result)-1]['parent_id'] = $v;
			}
			if ($k == 'type') {
				$result[count($result)-1]['type'] = $v;
			}
		});
		foreach($result as $values)
		{
			$id=$values['id'];
			$name=$values['name'];
			$parent=$values['parent_id'];
			$type=$values['type'];
			if($id!='sub')
			{
				if($id!='')
				{
					$this->db->query("UPDATE `elearning_topics` SET `standard_id`='$standard_id',`standard`='$standard',`subject_id`='$subject_id',`subject`='$subject',`name`='$name',`parent`='$parent',`type`='$type' WHERE `id`='$id'");
				}
				else{
					$this->db->query("INSERT INTO `elearning_topics`(`standard_id`, `standard`, `subject_id`, `subject`, `name`, `parent`,`type`, `added_date`) VALUES ('$standard_id','$standard','$subject_id','$subject','$name','$parent','$type','$added_date')");
				}
			}
		}
		return $this->get_chapter_topic($postdata);
	}
	
	public function delete_topic($postdata)
	{
		$data=json_decode($postdata,TRUE);
		$id=$data['id'];
		$standard_id=$data['standard_id'];
		$standard=$data['standard'];
		$subject_id=$data['subject_id'];
		$subject=$data['subject'];
		$this->db->query("DELETE FROM `elearning_topics` WHERE `standard_id`='$standard_id' AND `standard`='$standard' AND `subject`='$subject' AND `subject_id`='$subject_id' AND id='$id'");
	}

	public function update_content($postdata)
	{
		$data=json_decode($postdata,TRUE);
		$videos=$data['video'];
		$description=$data['des'];
		$documents=$data['docs'];
		$topic=$data['topic'];
		$date=date('Y-m-d H:i:s');
		foreach($documents as $docs=>$vals)
		{
			$file=$vals['o_name'];
			$id=$vals['id'];
			
			if($file!='')
			{
				if($vals['id']=='')
				{
					$this->db->query("INSERT INTO `elearning_documents`(`topic_id`, `filename`, `added_date`) VALUES ('$topic','$file','$date')");
				}
				else
				{
					$this->db->query("UPDATE `elearning_documents` SET `topic_id`='$topic',`filename`='$file' WHERE `id`='$id'");
				}
			}
		}
		foreach($videos as $video=>$val)
		{
			$url=$val['url'];
			$type=$val['type'];
			$id=$val['id'];
			if($url!='')
			{
				if($val['id']=='')
				{
					$this->db->query("INSERT INTO `elearning_videos`(`topic_id`, `type`, `url`, `added_date`) VALUES ('$topic','$type','$url','$date')");
				}
				else
				{
					$this->db->query("UPDATE `elearning_videos` SET `topic_id`='$topic',`type`='$type',`url`='$url' WHERE `id`='$id'");
				}
			}
		}
		if(isset($des_id))
		{
			$this->db->query("UPDATE `elearning_contents` SET `topic_id`='$topic',`content`='$description',`added_date`='$date' WHERE `id`='$id'");
		}
		else
		{
			$this->db->query("INSERT INTO `elearning_contents`(`topic_id`, `content`, `added_date`) VALUES ('$topic','$description','$date')");
		}
		return true;
	}

	public function get_content_by_topic($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$description='';
		$videos='';
		$docs='';
		$dquery=$this->db->query("SELECT * FROM `elearning_contents` WHERE topic_id='$id'");
		foreach ($dquery->result() as $row)
		{
			$description[]=array('des_id'=>$row->id,'des'=>$row->content);
		}
		$vquery=$this->db->query("SELECT * FROM `elearning_videos` WHERE topic_id='$id'");
		foreach ($vquery->result() as $row)
		{
			$videos[]=array('id'=>$row->id,'type'=>$row->type,'url'=>$row->url);
		}
		$fquery=$this->db->query("SELECT * FROM `elearning_documents` WHERE topic_id='$id'");
		foreach ($fquery->result() as $row)
		{
			$ext=pathinfo($row->filename, PATHINFO_EXTENSION);
			$docs[]=array('id'=>$row->id,'file'=>$row->filename,'ext'=>$ext);
		}
		return $datas=array('des'=>$description,'videos'=>$videos,'docs'=>$docs);

	}
	public function delete_video($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$this->db->query("DELETE FROM `elearning_videos` WHERE `id`='$id'");
	}
	public function delete_doc($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$this->db->query("DELETE FROM `elearning_documents` WHERE `id`='$id'");
	}
	
	public function buildTree(array $elements, $parentId = 0) {
		$branch = array();
	
		foreach ($elements as $element) {
			if ($element['parent_id'] == $parentId) {
				$children = $this->buildTree($elements, $element['id']);
				
					$element['nodes'] = $children;
				
				$branch[] = $element;
			}
		}
	
		return $branch;
	}
	
}

?>