<?php
Class Assignment extends CI_model{

	function get_assignment()
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=array();
		$query = $this->db->query("SELECT * FROM assignment WHERE `acd_year`='$acd_year' AND `status`='pending' ORDER BY `date` DESC");	
		foreach ($query->result() as $row)
		{
			
			$date=date_create($row->added_date);
			$date=date_format($date,"M j, Y");
			$data[]=array('id'=>$row->id,'name'=>$row->name,'description'=>$row->description,'date'=>$date);
		}
		return $data;
		
	}
	function assignment_list($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$acd_year=$user_data['acd_year'];
		$assignments=array();
		$where=array();
		if(isset($postdata->date))
		{
			$postdata->date=date("Y-m-d",strtotime($postdata->date));
			$date=array('date(added_date)'=>$postdata->date);
			$where=array_merge($where, $date);
		}
		
		if(isset($postdata->standard))
		{
			$standard=array('standard'=>$postdata->standard);
			$where=array_merge($where, $standard);
		}
		if(isset($postdata->division))
		{
			$division=array('division'=>$postdata->division);
			$where=array_merge($where, $division);
		}
		if(isset($postdata->course))
		{
			$course=array('course'=>$postdata->course);
			$where=array_merge($where, $course);
		}	
		if(isset($postdata->teacher))
		{
			$teacher=array('teacher_id'=>$postdata->teacher);
			$where=array_merge($where, $teacher);
		}	
		//print_r($where);
		// $standard=$postdata->standard;
		// $division=$postdata->division;
		// $course=$postdata->course;
		$query = $this->db->get_where('assignment', $where);
		
		$data=array();
		foreach ($query->result() as $row)
		{
			$course=$row->course;
			$standard=$row->standard;
			$division=$row->division;
			$teacher=$row->teacher_id;
			$subject=$row->subject;
			

			// $jsonData = array('params'=>array(
			// 	'course_id'=>(int)$course
			// )
			// );
			// $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			// $this->load->library('PHPRequests');
			// $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			// $response = Requests::post(API_PATH.'lms/dataset/getStandardList',$headers,$jsonDataEncoded);
			// $data=json_decode($response->body,true);
			// $datas=$data['result']; 
			// foreach($datas as $standards)
			// {
			// 	if($standard==$standards['standard_id'])
			// 	{
			// 		$standard_name=$standards['name'];
			// 		break;
			// 	}
			// }

			// $jsonData = array('params'=>array(
			// 	'standard_id' => (int)$standard
			// )
			// );
			// $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			// $this->load->library('PHPRequests');
			// $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			// $response = Requests::post(API_PATH.'lms/dataset/getDivisionList',$headers,$jsonDataEncoded);
			// $data=json_decode($response->body,true);
			// $datas=$data['result']; 
			// foreach($datas as $divisions)
			// {
			// 	if($division==$divisions['division_id'])
			// 	{
			// 		$division_name=$divisions['name'];
			// 		break;
			// 	}
			// }

			// $jsonData = array('params'=>array(
			// 	'standard_id'=>(int)$standard
			// )
			// );
			// $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			// $this->load->library('PHPRequests');
			// $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			// $response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
			// $data=json_decode($response->body,true);
			// $datas=$data['result']; 
			// foreach($datas as $subjects)
			// {
			// 	if($subject==$subjects['subject_id'])
			// 	{
			// 		$subject_name=$subjects['name'];
			// 		break;
			// 	}
			// }

			$jsonData = array('params'=>array(
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getTeachersList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $teachers)
			{
				if($teacher==$teachers['user_id'])
				{
					$teacher_name=$teachers['name'];
					break;
				}
			}
			$date=date_create($row->date);
			$date=date_format($date,"M j, Y");
			$created_date=date_create($row->added_date);
			$created_date=date_format($created_date,"M j, Y");
			$assignments[]=array('id'=>$row->id,'teacher'=>$teacher_name,'topic'=>$row->name,'description'=>$row->description,'date'=>$date,'created_date'=>$created_date);
		}
		if(isset($assignments))
		{
			return $assignments;
		}
		
	}
	function get_single_assignment($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$user_data=$this->session->userdata('loggedin');
		
		$assignment=array();
		$query = $this->db->query("SELECT * FROM assignment WHERE id='$id' ");	
		foreach ($query->result() as $row)
		{
			$course=$row->course;
			$standard=$row->standard;
			$division=$row->division;
			$teacher=$row->teacher_id;
			$subject=$row->subject;
			$jsonData = array('params'=>array(
				'course_id'=>(int)$course
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStandardList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $standards)
			{
				if($standard==$standards['standard_id'])
				{
					$standard_name=$standards['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
				'standard_id' => (int)$standard
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getDivisionList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $divisions)
			{
				if($division==$divisions['division_id'])
				{
					$division_name=$divisions['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
				'standard_id'=>(int)$standard
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getSubjectList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach($datas as $subjects)
			{
				if($subject==$subjects['subject_id'])
				{
					$subject_name=$subjects['name'];
					break;
				}
			}

			$jsonData = array('params'=>array(
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getTeachersList',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);//print_r($data);
			$datas=$data['result']; 
			foreach($datas as $teachers)
			{
				if($teacher==$teachers['user_id'])
				{
					$teacher_name=$teachers['name'];
					break;
				}
			}
			$date=date_create($row->date);
			$date=date_format($date,"M j, Y");
			$created_date=date_create($row->added_date);
			$created_date=date_format($created_date,"M j, Y");

			$att=$row->attachment;
			$attachment=array();
			if($att)
			{
				$att = preg_replace('/\.$/', '', $att); //Remove dot at end if exists
				$atts = explode(',', $att); //split string into array seperated by ', '
				
				
				foreach($atts as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$attachment[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			$answer_key=array();
			if($row->answer_key)
			{
				$answer=$row->answer_key;
				$answer = preg_replace('/\.$/', '', $answer); //Remove dot at end if exists
				$answer = explode(',', $answer); //split string into array seperated by ', '
				foreach($answer as $value) //loop over values
				{
					$qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$value'");
					$row1=$qry->row_array();
					$answer_key[]=array('id'=>$row1['id'],'name'=>$row1['name'],'type'=>$row1['type']);
				}
			}
			$assignment[]=array('id'=>$row->id,'standard'=>$standard_name,'division'=>$division_name,'subject'=>$subject_name,'teacher'=>$teacher_name,'topic'=>$row->name,'description'=>$row->description,'date'=>$date,'created_date'=>$created_date,'max_mark'=>$row->marks,'attachment'=>$attachment,'answer_key'=>$answer_key);
			// $data[]=array('id'=>$row->id,'course'=>$row->course,'standard'=>$row->standard,'division'=>$row->division,'subject'=>$row->subject,'marks'=>$row->marks,'name'=>$row->name,'topic'=>$row->name,'date'=>$date,'attachment'=>$attachment);
		}
		if(isset($assignment))
		{
			return $assignment;
		}
		else
		{
			return false;
		}
	}
	function get_students($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT * FROM assignment WHERE id='$id'");
		foreach ($query->result() as $row)
		{
			$assignment_name=$row->name;
			$max_mark=$row->marks;
			$jsonData = array('params'=>array(
				'standard_id'   =>(int)$row->standard,
				'division_id'   =>(int)$row->division
				)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
			$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'/lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$datas=$data['result']; 
			foreach ($datas as $sdata)
			{
				
				$sid=$sdata['id'];
				$aquery=$this->db->query("SELECT * FROM assignment_details WHERE student_id='$sid' AND assignment_id='$id'");
				
				//echo $aquery->num_rows();
				if($aquery->num_rows())
				{
					foreach ($aquery->result() as $arow)
					{ 
						$date=date_create($arow->submitted_date);
						$date=date_format($date,"F j, Y");
						$status='completed';
						$mark=$arow->mark;
						$description=$arow->description;
						$attachment=$arow->attachment;
						$review=$arow->review;
					}
				}
				else
				{
					$date='';
					$status='pending';
					$mark='';
					$description='';
					$attachment='';
					$review='';

				}
				$sdatas[]=array('id'=>$id,'sid'=>$sid,'assignment_name'=>$assignment_name,'max_mark'=>$max_mark,'name'=>$sdata['name'],'submitted_date'=>$date,'mark'=>$mark,'description'=>$description,'attachment'=>$attachment,'review'=>$review,'status'=>$status);
			}
		}
		return $sdatas;
	}
	public function add_assignment($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);
		
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$subject=$data->subject;
		$name=$data->name;
		$description=$data->description;
		$date=$data->date;
		$mark=$data->mark;
		$date=date("Y-m-d",strtotime($data->date));
		$description=$data->description;
		
		if(isset($data->attachment))
		{
			
			foreach($data->attachment as $att)
			{
				if(isset($attachment))
				{
					$attachment .=','.$att->id;
				}
				else
				{
					$attachment=$att->id;
				}
			}
		}
		
		$added_date=date('Y-m-d H:i:s');
		
		if($query = $this->db->query("INSERT INTO `assignment`(`teacher_id`, `course`, `standard`, `division`, `subject`, `name`, `description`, `date`, `marks`, `attachment`, `added_date`,`acd_year`) VALUES ('$teacher_id','$course','$standard','$division','$subject','$name','$description','$date','$mark','$attachment','$added_date','$acd_year')"))
		{
			return $data=array('status'=>'success','msg'=>'Assignment Published Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Publishing Assignment');			
		}
	}

	function assignment_edit($postdata)
	{
		$user_data=$this->session->userdata('loggedin');
		$teacher_id=$user_data['uid'];
		$acd_year=$user_data['acd_year'];
		$data=json_decode($postdata);
		$id=$data->id;
		$course=$data->course;
		$standard=$data->standard;
		$division=$data->division;
		$subject=$data->subject;
		$name=$data->name;
		$description=$data->description;
		$mark=$data->mark;
		$date=date("Y-m-d",strtotime($data->date));
		$description=$data->description;
		
		if(isset($data->attachment))
		{
			$qry=$this->db->query("SELECT `attachment` FROM `assignment` WHERE `id`='$id'");
			$at_row=$qry->row_array();
			$at_row['attachment'];
			$existing_ids=$at_row['attachment'];
			$existing_ids=explode(',',$existing_ids);
			foreach($data->attachment as $att)
			{
				
				if(isset($attachment))
				{
					$attachment .=','.$att->id;
				}
				else
				{
					$attachment=$att->id;
				}
			}
			$current_ids=explode(',',$attachment);
			foreach($existing_ids as $existing)
			{
				if(!in_array($existing, $current_ids))
				{
					$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$existing'");
					$row=$at_qry->row_array();
					$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
					unlink($file);
					$this->db->query("DELETE FROM assignment_attachments WHERE id='$existing'");
				}
			}
		}
		else{
			$attachment='';
			$qry=$this->db->query("SELECT `attachment` FROM `assignment` WHERE `id`='$id'");
			$at_row=$qry->row_array();
			$at_row['attachment'];
			$existing_ids=$at_row['attachment'];
			$existing_ids=explode(',',$existing_ids);
			foreach($existing_ids as $existing)
			{
				$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$existing'");
				$row=$at_qry->row_array();
				$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
				unlink($file);
				$this->db->query("DELETE FROM assignment_attachments WHERE id='$existing'");
			}
		}
		if(isset($data->new_attachments))
		{
			foreach($data->new_attachments as $atts)
			{				
				if(isset($attachments))
				{
					$attachments .=','.$atts->id;
				}
				else
				{
					$attachments=$atts->id;
				}
			}
		}
		if(isset($attachments))
		{
			$attachment=$attachment.','.$attachments;
		}

		$added_date=date('Y-m-d H:i:s');
		
		if($query = $this->db->query("UPDATE `assignment` SET `teacher_id`='$teacher_id', `course`='$course', `standard`='$standard', `division`='$division', `subject`='$subject', `name`='$name', `description`='$description', `date`='$date', `marks`='$mark', `attachment`='$attachment' WHERE id='$id'"))
		{
			return $data=array('status'=>'success','msg'=>'Assignment Updated Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Updating Assignment');			
		}
	}
	
	function submit_assignment_review($postdata)
	{
		$data=json_decode($postdata);
		$asid=$data->asid;
		$sid=$data->sid;
		$mark=$data->mark;
		$review=$data->review;
		if($this->db->query("UPDATE assignment_details SET `mark`='$mark',`review`='$review' WHERE assignment_id='$asid' AND student_id='$sid'"))
		{
			$id=$asid;
			$url='#/assignment_view/'.$id;
			$this->db->query("INSERT INTO `student_notifications`( `to_id`, `module`, `item_id`, `url`, `message`, `date`) VALUES ('$sid','assignment','$id','$url','Teacher reviewed your assignment','$added_date')");
			return true;
		}
	}

	function delete_assignment($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$query=$this->db->query("SELECT attachment FROM assignment WHERE id='$id'");
		$row=$query->row_array();
		$attachments=explode(',',$row['attachment']);
		foreach($attachments as $atts)
		{
			$at_qry=$this->db->query("SELECT * FROM assignment_attachments WHERE id='$atts'");
			$row=$at_qry->row_array();
			$file='uploads/'.$this->conf->common->school_code.'/assignments/'.$row['name'];
			unlink($file);
			$this->db->query("DELETE FROM assignment_attachments WHERE id='$atts'");
		}
		if($this->db->query("DELETE FROM assignment WHERE id='$id'"))
		{
			$this->db->query("DELETE FROM assignment_details WHERE assignment_id='$id'");
			return $data=array('status'=>'success','msg'=>'Assignment Deleted Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Error Deleting Assignment');
		}
	}
function reject_assignment($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$date=date('Y-m-d H:i:s');
		$qry=$this->db->query("SELECT * FROM assignment WHERE id='$id'");
		$row=$qry->row_array();
		$note=$row['notes'];
		$note=json_decode($note,true);
		$note[]=array('date'=>$date,'note'=>$postdata->note);
		$note=json_encode($note);

		$query=$this->db->query("UPDATE assignment SET `notes`='$note', `status`='rejected'  WHERE id='$id'");
		
		if($query)
		{
			
			return $data=array('status'=>'success','msg'=>'Assignment Rejected');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
		}
	}
	function approve_assignment($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		$query=$this->db->query("UPDATE assignment SET `status`='approved'  WHERE id='$id'");
		if($query)
		{
			
			return $data=array('status'=>'success','msg'=>'Assignment Approved Successfully');
			
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
			
		}
	}
	function send_notification($postdata)
	{
		$postdata=json_decode($postdata);
		$id=$postdata->id;
		
		$qry=$this->db->query("SELECT * FROM assignment WHERE id='$id'");
		$row=$qry->row_array();
    	$user_data=$this->session->userdata('loggedin');
		$jsonData = array('params'=>array(
			'standard_id'    =>(int)$row['standard'],
			'division_id'    =>(int)$row['division']
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {         	
                $data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>"You have a new Assignment.", 'type'=>'assignment','sound'=>"common_alert.wav");
            	$jsonData = array(
				'student_id'    =>$student['id'],
                "data"=>$data_content
				);
				$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
				$this->load->library('PHPRequests');
        		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
				$response = Requests::post(API_PATH.'staging-api/notification/send_student_push_notification',$headers,$jsonDataEncoded);
           		
				$data=json_decode($response->body,true);print_r($data);
			}
	}
	function approve_multiple_assignment($postdata)
	{
		$postdata=json_decode($postdata);
		//$ids=$postdata->id;
		$error='0';
		foreach($postdata as $id )
		{
			if($this->db->query("UPDATE assignment SET `status`='approved'  WHERE id='$id'"))
			{
				$error='0';
			}
			else
			{
				$error='1';
			}
		}
		
		
		if($error=='0')
		{
			
			return $data=array('status'=>'success','msg'=>'Assignment Approved Successfully');
		}
		else
		{
			return $data=array('status'=>'error','msg'=>'Unknown error');
		}
	}

	function send_multiple_notification($postdata)
	{
		$postdata=json_decode($postdata);
		//$ids=$postdata->id;		
		foreach($postdata as $id )
		{
			

			$qry=$this->db->query("SELECT * FROM assignment WHERE id='$id'");
			$row=$qry->row_array();
    		$user_data=$this->session->userdata('loggedin');
			$jsonData = array('params'=>array(
			'standard_id'    =>(int)$row['standard'],
			'division_id'    =>(int)$row['division']
			)
			);
			$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
			$this->load->library('PHPRequests');
        	$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
			$response = Requests::post(API_PATH.'lms/dataset/getStudentListByDivision',$headers,$jsonDataEncoded);
			$data=json_decode($response->body,true);
			$students=$data['result'];
        	foreach($students as $student)
            {
            	
            	
                $data_content=array('id'=>$id,'title'=>'Smart School Pro', 'body'=>" You have a new Assignment.", 'type'=>'assignment','sound'=>"common_alert.wav");
            	$jsonData = array(
				'student_id'    =>$student['id'],
                "data"=>$data_content
				);
				$jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
				$this->load->library('PHPRequests');
        		$headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
				$response = Requests::post(API_PATH.'staging-api/notification/send_student_push_notification',$headers,$jsonDataEncoded);
           		
				$data=json_decode($response->body,true);print_r($data);
			}
		}
		
	}
}

?>