<?php
Class Lessonplanner extends CI_model{
    function get_chapter($postdata)
    {
        $postdata=json_decode($postdata);
        $chapter=$postdata->chapter;
        $query=$this->db->query("SELECT * FROM `elearning_topics` WHERE `type`='c' AND `name` like '%$chapter%'");
        foreach($query->result() as $row)
        {
            $data[]=array('name'=>$row->name);
        }
        if(isset($data))
		{
			return $data;
		}
    }
    function get_topics($postdata)
    {
        $postdata=json_decode($postdata);
        $topic=$postdata->topic;
        $query=$this->db->query("SELECT * FROM `elearning_topics` WHERE `type`='t' AND `name` like '%$topic%'");
        foreach($query->result() as $row)
        {
            $data[]=array('name'=>$row->name);
        }
        if(isset($data))
		{
			return $data;
		}
    }
    function add_plan($postdata)
    {
        $postdata=json_decode($postdata);
        $user_data=$this->session->userdata('loggedin');
        $teacher_id=$user_data['uid'];
        $acd_year=$user_data['acd_year'];
        $added_date=date('Y-m-d H:i:s');
        $course=$postdata->course;
        $standard=$postdata->standard;
        $divisions= $postdata->division;
        $subject=$postdata->subject;
        $chapter=$postdata->chapter;
        $topic=$postdata->topic;
        $date=date("Y-m-d",strtotime($postdata->date));
        $teacher_id=$teacher_id;
        foreach($divisions as $division_item){
            $division = $division_item->id;
            $query=$this->db->query("INSERT INTO `lesson_planner`(`teacher_id`, `course`, `standard`, `division`, `subject`, `chapter`, `topic`, `date`, `status`, `added_date`,`acd_year`) VALUES ('$teacher_id','$course','$standard','$division','$subject','$chapter','$topic','$date','false','$added_date','$acd_year')");
        }
            
        return true;
    }

    function list_plans()
    {
        $user_data=$this->session->userdata('loggedin');
        $teacher_id=$user_data['uid'];
        $acd_year=$user_data['acd_year'];
        $query=$this->db->query("SELECT * FROM `lesson_planner` WHERE acd_year='$acd_year'");
        foreach($query->result() as $row)
        {
            $date=date_create($row->date);
            $date=date_format($date,"F j, Y");
            
            $cdate=date_create($row->completed_date);
            $cdate=date_format($cdate,"F j, Y");

            $data[]=array('id'=>$row->id,'chapter'=>$row->chapter,'topic'=>$row->topic,'due_date'=>$date,'completed_date'=>$cdate,'status'=>$row->status);
        }
        if(isset($data))
        {
            return $data;
        }
    }
    function plan_details($id)
    {
        $query=$this->db->query("SELECT * FROM `lesson_planner` WHERE id='$id'");
        $row=$query->row_array();
        $date=date('F j, Y',strtotime($row['date']));
        if($row['completed_date']!='0000-00-00 00:00:00')
        {
            $cdate=date('F j, Y',strtotime($row['completed_date']));
        }
        else
        {
            $cdate='';
        }
        $course=$row['course'];
        $user_data=$this->session->userdata('loggedin');
        $jsonData = array('params'=>array(
        'data_type' =>'course',
        'id'  =>(int)$course
        )
        );
        $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
        $this->load->library('PHPRequests');
        $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
        $response = Requests::post(API_PATH.'lms/dataset/getDataById',$headers,$jsonDataEncoded);
        $data=json_decode($response->body,true);
        $course_name=$data['result'];

        $standard=$row['standard'];
        $user_data=$this->session->userdata('loggedin');
        $jsonData = array('params'=>array(
        'data_type' =>'standard',
        'id'  =>(int)$standard
        )
        );
        $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
        $this->load->library('PHPRequests');
        $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
        $response = Requests::post(API_PATH.'lms/dataset/getDataById',$headers,$jsonDataEncoded);
        $data=json_decode($response->body,true);
        $standard_name=$data['result'];

        $division=$row['division'];
        $user_data=$this->session->userdata('loggedin');
        $jsonData = array('params'=>array(
        'data_type' =>'division',
        'id'  =>(int)$division
        )
        );
        $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
        $this->load->library('PHPRequests');
        $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
        $response = Requests::post(API_PATH.'lms/dataset/getDataById',$headers,$jsonDataEncoded);
        $data=json_decode($response->body,true);
        $division_name=$data['result'];

        $subject=$row['subject'];
        $user_data=$this->session->userdata('loggedin');
        $jsonData = array('params'=>array(
        'data_type' =>'subject',
        'id'  =>(int)$subject
        )
        );
        $jsonDataEncoded = json_encode($jsonData,JSON_UNESCAPED_SLASHES);
        $this->load->library('PHPRequests');
        $headers = array('Content-Type' => 'application/json','Cookie' => 'session_id='.$user_data['session_id']);
        $response = Requests::post(API_PATH.'lms/dataset/getDataById',$headers,$jsonDataEncoded);
        $data=json_decode($response->body,true);
        $subject_name=$data['result'];


        $data=array('id'=>$row['id'],'chapter'=>$row['chapter'],'topic'=>$row['topic'],'due_date'=>$date,'completed_date'=>$cdate,'status'=>$row['status'],'standard'=>$standard_name,'division'=>$division_name,'subject'=>$subject_name,'course'=>$course_name);
        return $data;
    }

    function change_status($id,$status)
    {
        if($status=='true')
        {
            $completed=date('Y-m-d H:i:s');
        }
        else
        {
            $completed="";
        }
        $query=$this->db->query("UPDATE `lesson_planner` SET status='$status',completed_date='$completed' WHERE id='$id'");
        if($query)
        {
            return true;
        }
    }
}
?>