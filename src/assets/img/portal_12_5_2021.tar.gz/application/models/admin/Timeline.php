<?php
Class Timeline extends CI_model{
	function post($postdata)
	{
		$data=json_decode($postdata,TRUE);
		$image=$data['image'];
		$videos=$data['video'];
		if(isset($data['des']))
		{
			$description=$data['des'];
		}
		else
		{
			$description='';
		}
		if(isset($data['youtube']))
		{
			$youtube=$data['youtube'];
		}
		else
		{
			$youtube='';
		}
		$user_data=$this->session->userdata('loggedin');
		$user_id=$user_data['student_id'];
		$user_name=$user_data['name'];
		$user_photo=$user_data['photo'];
		$acd_year=$user_data['acd_year'];
		$date=date('Y-m-d H:i:s');
		$this->db->query("INSERT INTO `timeline_posts`(`user_id`,`user_name`,`user_photo`, `description`, `added_date`,`acd_year`) VALUES ('$user_id','$user_name','$user_photo','$description','$date','$acd_year')");
		$post_id=$this->db->insert_id();
		if($image!=null)
		{
			foreach($image as $images=>$val)
			{
				$name=base_url().'uploads/'.$this->conf->common->school_code.'/timeline/'.$val['name'];
				$type=$val['type'];
				$id=$val['id'];
				if($val['name']!='')
				{
					$this->db->query("INSERT INTO `timeline_post_content`(`post_id`,`type`, `content`, `added_date`) VALUES ('$post_id','$type','$name','$date')");
				}
			}
		}
		if($videos!=null)
		{
			$videos=str_replace('/videos/','',$videos);
			$this->db->query("INSERT INTO `timeline_post_content`(`post_id`,`type`, `content`, `added_date`) VALUES ('$post_id','video_upload','$videos','$date')");
		}
		if($youtube!='')
		{
			$this->db->query("INSERT INTO `timeline_post_content`(`post_id`,`type`, `content`, `added_date`) VALUES ('$post_id','youtube','$youtube','$date')");
		}
		$post_content=array();
		
		$cquery=$this->db->query("SELECT * FROM `timeline_post_content` WHERE post_id='$post_id'");
		foreach($cquery->result() as $row1)
		{
			$youtube_id='';
			$thumbnail='';
			$content=$row1->content;
			$regex_pattern = "/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/";
			$match;
			if($row1->type=='youtube')
			{
				if(preg_match($regex_pattern, $content, $match)){
					preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $content, $match);
					$youtube_id = $match[1];
				}
			}
			if($row1->type=='video_upload')
			{
				$hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/".$row1->content.".php"));
				$thumbnail=$hash[0]['thumbnail_large'];
			}
			$post_content[]=array('type'=>$row1->type,'content'=>$row1->content,'youtube_id'=>$youtube_id,'thumbnail'=>$thumbnail);
		}
		$date=date("F jS, Y", strtotime($date));
		$post_data=array('id'=>$post_id,'user_id'=>$user_id,'user_name'=>$user_name,'user_photo'=>$user_photo,'des'=>$description,'show_edit'=>'1','likes'=>'0','you_like'=>'','date'=>$date,'content'=>$post_content);
		return $post_data;
	} 

	function get_post($postdata)
	{
		$data=json_decode($postdata);
		$start=$data->start;
		$end=$data->end;
		$user_data=$this->session->userdata('loggedin');
		$cur_id=$user_data['student_id'];
		$acd_year=$user_data['acd_year'];
		$post_content=array();
		$post_comment=array();
		$query=$this->db->query("SELECT * FROM `timeline_posts` WHERE `acd_year`='$acd_year' ORDER BY `added_date` DESC LIMIT $start,$end");
		foreach($query->result() as $row)
		{
			$cmntquery=$this->db->query("SELECT * FROM `timeline_post_comments` WHERE post_id='$row->id'");
			foreach($cmntquery->result() as $crow)
			{
				$post_comment[]=array('id'=>$crow->id,'post_id'=>$crow->post_id,'user_id'=>$crow->user_id,'user_name'=>$crow->user_name,'user_photo'=>$crow->user_photo,'comment'=>$crow->comment);
			}
			if($row->type=='share')
			{
				$post_id=$row->parent;
			}
			else{
				$post_id=$row->id;
			}
			
			$cquery=$this->db->query("SELECT * FROM `timeline_post_content` WHERE post_id='$post_id'");
			$post_content=array();
			foreach($cquery->result() as $row1)
			{
				$youtube_id='';
				$thumbnail='';
				$content=$row1->content;
				$regex_pattern = "/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/";
				$match;
				if($row1->type=='youtube')
				{
					if(preg_match($regex_pattern, $content, $match)){
						preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $content, $match);
						$youtube_id = $match[1];
					}
				}
				if($row1->type=='video_upload')
				{

					$hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/".$row1->content.".php"));
					$thumbnail=$hash[0]['thumbnail_large'];
				}
				$post_content[]=array('type'=>$row1->type,'content'=>$row1->content,'youtube_id'=>$youtube_id,'thumbnail'=>$thumbnail);
			}
			
			
			if($row->user_id==$cur_id)
			{
				$show_edit='1';
			}
			else{
				$show_edit='0';
			}
			$like_query=$this->db->query("SELECT * FROM `timeline_post_likes` WHERE post_id='$row->id'");
			$like_count=$like_query->num_rows();
			$you_liked=$this->db->query("SELECT * FROM `timeline_post_likes` WHERE post_id='$row->id' AND `user_id`='$cur_id'");
			$you_liked_count=$you_liked->num_rows();
			if($you_liked_count>0)
			{
				$youlike='true';
			}
			else{
				$youlike='';
			}
			$date=date("j F Y", strtotime($row->added_date));
			$pname='';
			$status='';
			if($row->type=='share')
			{
				$pid=$row->parent;
				$pquery=$this->db->query("SELECT `user_name` FROM `timeline_posts` WHERE id='$pid'");
				$cnt=$pquery->num_rows();
				if($cnt<=0)
				{
					$status='deleted';
				}
				$prow=$pquery->row_array();
				$pname=$row->parent_name;
			}
			
			$post_data[]=array('id'=>$row->id,'user_id'=>$row->user_id,'user_name'=>$row->user_name,'user_photo'=>$row->user_photo,'des'=>$row->description,'show_edit'=>$show_edit,'likes'=>$like_count,'you_like'=>$youlike,'date'=>$date,'type'=>$row->type,'parent'=>$row->parent,'pname'=>$pname,'content'=>$post_content,'comment'=>$post_comment,'status'=>$status);
			$post_content=array();
			$post_comment=array();
		}
		if(isset($post_data))
		return $post_data;
	}

	function like_post($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$user_data=$this->session->userdata('loggedin');
		$user_id=$user_data['student_id'];
		$user_name=$user_data['name'];
		$date=date('Y-m-d H:i:s');
		$likedq=$this->db->query("SELECT * FROM timeline_post_likes WHERE `post_id`='$id' AND `user_id`='$user_id'");
		$liked=$likedq->num_rows();
		if($liked>0)
		{
			$this->db->query("DELETE FROM `timeline_post_likes` WHERE  `post_id`='$id' AND `user_id`='$user_id'");
		}
		else
		{
			$this->db->query("INSERT INTO `timeline_post_likes`(`user_id`, `user_name`, `post_id`, `added_date`) VALUES ('$user_id','$user_name','$id','$date')");
		}
		
	}

	function share_post($postdatas)
	{
		$data=json_decode($postdatas);
		$id=$data->id;		
		$user_data=$this->session->userdata('loggedin');
		$user_id=$user_data['student_id'];
		$user_name=$user_data['name'];
		$user_photo=$user_data['photo'];
		$acd_year=$user_data['acd_year'];
		$date=date('Y-m-d H:i:s');
		$query=$this->db->query("SELECT * FROM `timeline_posts` WHERE id='$id'");
		foreach($query->result() as $row)
		{
			if($row->type=='share')
			{
				$parent=$row->parent;
				$parent_name=$row->parent_name;
			}
			else
			{
				$parent=$row->id;
				$parent_name=$row->user_name;
			}
			$this->db->query("INSERT INTO `timeline_posts`(`user_id`,`user_name`,`user_photo`, `description`,`type`,`parent`, `parent_name`,`added_date`,`acd_year`) VALUES ('$user_id','$user_name','$user_photo','$row->description','share','$parent','$parent_name','$date','$acd_year')");
			$description=$row->description;
		}
		
		$post_id=$this->db->insert_id();
		$post_content=array();
		$cquery=$this->db->query("SELECT * FROM `timeline_post_content` WHERE post_id='$id'");
		foreach($cquery->result() as $row1)
		{
			$youtube_id='';
			$thumbnail='';
			$content=$row1->content;
			$regex_pattern = "/(youtube.com|youtu.be)\/(watch)?(\?v=)?(\S+)?/";
			$match;
			if($row1->type=='youtube')
			{
				if(preg_match($regex_pattern, $content, $match)){
					preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $content, $match);
					$youtube_id = $match[1];
				}
			}
			if($row1->type=='video_upload')
			{
				$hash = unserialize(file_get_contents("http://vimeo.com/api/v2/video/".$row1->content.".php"));
				$thumbnail=$hash[0]['thumbnail_large'];
			}
			$post_content[]=array('type'=>$row1->type,'content'=>$row1->content,'youtube_id'=>$youtube_id,'thumbnail'=>$thumbnail);
		}
		$date=date("F jS, Y", strtotime($date));
		$pquery=$this->db->query("SELECT `user_name` FROM `timeline_posts` WHERE id='$id'");
		$prow=$pquery->row_array();
		$pname=$prow['user_name'];
		$post_data=array('id'=>$post_id,'user_id'=>$user_id,'user_name'=>$user_name,'user_photo'=>$user_photo,'des'=>$description,'show_edit'=>'1','likes'=>'0','you_like'=>'','date'=>$date,'type'=>'share','parent'=>$id,'pname'=>$pname,'content'=>$post_content);
		return $post_data;
	} 

	function comment($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		$comment=$data->comment;
		$user_data=$this->session->userdata('loggedin');
		$user_id=$user_data['student_id'];
		$user_name=$user_data['name'];
		$user_photo=$user_data['photo'];
		$date=date('Y-m-d H:i:s');
		$likedq=$this->db->query("SELECT * FROM timeline_post_likes WHERE `post_id`='$id' AND `user_id`='$user_id'");
		$liked=$likedq->num_rows();
		$this->db->query("INSERT INTO `timeline_post_comments`(`user_id`, `user_name`, `user_photo`, `post_id`, `comment`, `added_date`) VALUES ('$user_id','$user_name','$user_photo','$id','$comment','$date')");
	}

	function remove_post($postdata)
	{
		$data=json_decode($postdata);
		$id=$data->id;
		if($this->db->query("DELETE FROM timeline_posts WHERE id='$id'"))
		{
			if($this->db->query("DELETE FROM timeline_post_comments WHERE post_id='$id'"))
			{
				if($this->db->query("DELETE FROM timeline_post_content WHERE post_id='$id'"))
				{
					if($this->db->query("DELETE FROM timeline_post_likes WHERE post_id='$id'"))
					{
						return $data=array("msg"=>"Post Deleted Successfully","status"=>"success");
					}
					else{
						return $data=array("msg"=>"Error Deleting Post","status"=>"error");
					}
				}
				else{
					return $data=array("msg"=>"Error Deleting Post","status"=>"error");
				}
			}
			else{
				return $data=array("msg"=>"Error Deleting Post","status"=>"error");
			}
		}
		else{
			return $data=array("msg"=>"Error Deleting Post","status"=>"error");
		}
	}
	
}
?>