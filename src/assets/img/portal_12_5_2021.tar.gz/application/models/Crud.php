<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Model 
{
    // private $db;
	// private $db_name;
	public function __construct()
	{
		parent::__construct();
		// $config['hostname'] = "localhost";
		// $config['username'] = "myadmin";
		// $config['password'] = "Myadmin@123#";
		// $config['database'] = "admin_demo";
		// $config['dbdriver'] = "mysqli";
		// $config['dbprefix'] = "";
		// $config['pconnect'] = FALSE;
		// $config['db_debug'] = TRUE;
		// $config['cache_on'] = FALSE;
		// $config['cachedir'] = "";
		// $config['char_set'] = "utf8";
		// $config['dbcollat'] = "utf8_general_ci";	
		// $this->db = $this->load->database($config, TRUE);
		
	}
    function addContent($data,$table)
    {
        if($this->db->insert($table,$data))
        {
            echo "Success";
        }
        else
        {
            echo "Error";
        }
    }
    function addeContent($data,$table)
    {
        if($this->db->insert($table,$data))
        {
           return true;
        }
        else
        {
           return false;
        }
    }
    public function listItems($table)
    {
        $query= $this->db->get($table); 
        return $query->result();   
    }
    public function deleteItem($id,$table)
    {
        if($this->db->delete($table, array('id' => $id)))
        {
            return true;
        }
        else
        {
           return false;
        }  
    }
    public function switchStatus($id,$table,$status)
    {
        $data=array('status'=>$status);
        if($table=='users')
        {
            $array=array('user_id' => $id);
        }
        else{
            $array=array('id' => $id);
        }
        if($this->db->update($table, $data, $array))
        {
            echo "Success";
        }
        else
        {
            echo "Error";
        }  
    }

    

    public function getItem($id,$table)
    {
        $query= $this->db->get_where($table, array('id' => $id)); 
        return $query->result();   
    }

    public function updateContent($id,$data,$table)
    {
        if($this->db->update($table, $data, array('id' => $id)))
        {
            return true;
        }
        else
        {
            return false;
        }  
    }

    public function itemCount($table)
    {
        $query= $this->db->get($table);
        return $query->num_rows();
    }

    public function getItemByCategory($cat,$table)
    {
        $query= $this->db->get_where($table, $cat); 
        return $query->result();   
    }
    public function updateUser($id,$data,$table)
    {
        if($this->db->update($table, $data, array('user_id' => $id)))
        {
            echo "Success";
        }
        else
        {
            echo "Error";
        }  
    }
}
?>